//20160731

#include "MIND.h"


U8 SR1[7], SG1[7], SB1[7], SR2[7], SG2[7], SB2[7];

EGL_COLOR Sclr[7] = {MAKE_COLORREF(255, 255, 255),MAKE_COLORREF(50, 50, 50),MAKE_COLORREF(255, 255, 0),
		MAKE_COLORREF(0, 0, 255), MAKE_COLORREF(255, 0, 0),MAKE_COLORREF(0, 255, 0),MAKE_COLORREF(255, 69, 0)};


const int cW = 180/cell;
const int cH = 120/cell;

void show_help(void)
{
	printf("================================================================\n");
	printf("<M I N D>\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("a : direct camera display on\n");
	printf("p : Pose Capture \n");
	printf("c : show colored image (o is return)\n");
	printf("s : control the parameters for color fitering (1~=)\n");
	printf("m : make a chained map\n");
	printf("b : active detected chains\n");
	printf("q : exit \n");
	printf("================================================================\n");
}

int main(void)
{
	int loop=1;

	sdataload();
	
	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U8* clrmap = (U8*)malloc(180*120);
	U32* chmap = (U32*)malloc(180*120);
	Chain* CHbuff = (Chain*)malloc(180*5);

	if (open_graphic() < 0) {
		return -1;
	}

	show_help();
	
	do{
		int ch = getchar();
		U32 act;

		switch(ch)
		{
			case 'Q':
			case 'q': loop = 0; 
			sdatawrite();
			break;// quit

			case 'H':
			case 'h':
			show_help();
			break;

			case 'A':
			case 'a':
			printf("direct camera display on\n");
			direct_camera_display_on();
			break;

			case 'P':
			case 'p':
			printf("Now fpga video data\n");
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;//fpga image read & draw the image

			case 'C':
			case 'c':
			printf("Colored Image\n");
			direct_camera_display_off();
			coloring(fpga_videodata,clrmap);
			flip();
			break;// flitering videodata to colored image & draw

			case 'M':
			case 'm':
			printf("Make Chain up\n");
			direct_camera_display_off();
			coloring(fpga_videodata,clrmap);
			mkchain(clrmap,chmap);
			CHclassfier(CHbuff,  chmap);
			flip();
			break;// flitering videodata to colored image & draw

			case 'B':
			case 'b':
			printf("Activate the detected chains\n");
			direct_camera_display_off();
			scanf("%08x",&act);
			coloring(fpga_videodata,clrmap);
			actCH(chmap,act);
			flip();
			break;// flitering videodata to colored image & draw

			case 'O':
			case 'o':
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;

			case 'S':
			case 's':
			direct_camera_display_off();
			standard(fpga_videodata,clrmap);
			break;
			}

	}while(loop);


	free(fpga_videodata);
	close_graphic();

	return 0;
}


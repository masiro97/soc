#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <fcntl.h>
#include <unistd.h>

#include "uart_api.h"

#include <termios.h>
static struct termios inittio, newtio;


#define SCI_BUF_SIZE   4

#define START_CODE    0xFF
#define START_CODE1   0x55
#define Hdata	      0x00
#define Hdata1        0xFF

#define ERROR	0
#define OK	1



void init_console(void);

void DelayLoop(int delay_time);
void Send_Command(unsigned char Ldata, unsigned char Ldata1);
int TestItemSelectRobot(void);


void init_stand(void);
void init_walk(void);
void init_walk_t(void);
void leftt(void);
void rightt(void);
void leftw(void);
void rightw(void);

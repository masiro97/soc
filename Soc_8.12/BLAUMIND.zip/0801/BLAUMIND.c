//20160801

#include "BLAU.h"
#include "MIND.h"

int AI=0;

U8 SR1[7], SG1[7], SB1[7], SR2[7], SG2[7], SB2[7];

EGL_COLOR Sclr[7] = {MAKE_COLORREF(255, 255, 255),MAKE_COLORREF(50, 50, 50),MAKE_COLORREF(255, 255, 0),
		MAKE_COLORREF(0, 0, 255), MAKE_COLORREF(255, 0, 0),MAKE_COLORREF(0, 255, 0),MAKE_COLORREF(255, 69, 0)};


const int cW = 180/cell;
const int cH = 120/cell;

void show_help(void)
{
	printf("================================================================\n");
	printf("                        <B L A U I N D>\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("i : camera on & Robot Init\n");
	printf("t : test Robot motion\n");
	printf("s : control the parameters for color fitering (1~=)\n");
	printf("m : make a chained map\n");
	printf("b : active detected chains\n");
	printf("q : exit \n");
	printf("========If you want AI mode, type with a command '-ai'========\n");
}

static int ParseOptions(int argc, char *argv[])
{
    int i = 1;

    if(i < argc && argv[i][0] == '-')
    {
        while(i < argc && argv[i][0] == '-')
        {
            if(i > 1 && argv[i][1] == '-')
            {
                printf("Using basic and custom options together is not supported\n");
                return 0;
            }

            // Get options
            if(!strcmp(argv[i], "-ai")) AI=TRUE;
            else
            {
                printf("%s is not a supported option\n If you want AI mode, type with a command '-ai'\n", argv[i]);
                return 0;
            }

            i++;
        }
    }

    if(i < argc)
    {
         printf("%s is not a supported option\n If you want AI mode, type with a command '-ai'", argv[i]);
        return 0;
    }

    // Check for consistency
    if(i < 2) AI=false;

    return 1;
}



int main(int argc, char *argv[])
{
 	if(!ParseOptions(argc, argv)) return -1;

	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U8* clrmap = (U8*)malloc(180*120);
	U32* chmap = (U32*)malloc(180*120);
	Chain* CHbuff = (Chain*)malloc(180*5);

	sdataload();

	init_console();
	if (uart_open() < 0) return -1;
	uart_config(UART1, 57600, 8, UART_PARNONE, 1);
	
	if (open_graphic() < 0) {
		return -1;
	}


	if(AI){
		printf("AUTO MODE\n");
		printf("camera on & Robot Init\n");
		direct_camera_display_on();
		init_stand();

		do{
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();

			coloring(fpga_videodata,clrmap);

			mkchain(clrmap,chmap);

			

			
		}while(TRUE);

	}
	else{
		int loop=1;

		show_help();
		//||----------------------------configure mode------------------------------||
		do{
			int ch = getchar();
			U32 act;

			switch(ch)
			{
				case 'q': loop = 0; 
				sdatawrite();
				break;// quit

				case 'h':
				show_help();
				break;

				case 'i':
				printf("camera on & Robot Init\n");
				direct_camera_display_on();
				init_stand();
				break;

				case 't':
				printf("t : test Robot motion\n");
				TestItemSelectRobot();
				break;

				case 'm':
				printf("Make Chain up\n");
				read_fpga_video_data(fpga_videodata);
				direct_camera_display_off();
				coloring(fpga_videodata,clrmap);
				mkchain(clrmap,chmap);
				CHclassfier(CHbuff,  chmap);
				flip();
				break;// flitering videodata to colored image & draw

				case 'b':
				printf("Activate the detected chains\n");
				direct_camera_display_off();
				scanf("%08x",&act);
				coloring(fpga_videodata,clrmap);
				actCH(chmap,act);
				flip();
				break;// flitering videodata to colored image & draw

				case 'o':
				direct_camera_display_off();
				draw_fpga_video_data_full(fpga_videodata);
				flip();
				break;

				case 's':
				direct_camera_display_off();
				standard(fpga_videodata,clrmap);
				break;
				}

		}while(loop);
		//||------------------------------------------------------------------------||
	}

	free(fpga_videodata);
	free(clrmap);
	free(chmap);
	free(CHbuff);
	close_graphic();
	uart_close();

	return 0;
}


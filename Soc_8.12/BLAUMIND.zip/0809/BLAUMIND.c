//20160809

#include "BLAU.h"
#include "MIND.h"

#include "amazon2_timer_api.h"
#define USING_TIMER 2

#define Cntr(gp) (gp.Csum/gp.num_of_group)


int AI=0; int COUNT=10*60;
int count_num=-1;

U8 SR1[7], SG1[7], SB1[7], SR2[7], SG2[7], SB2[7];

EGL_COLOR Sclr[7] = {MAKE_COLORREF(255, 255, 255),MAKE_COLORREF(50, 50, 50),MAKE_COLORREF(255, 255, 0),
		MAKE_COLORREF(0, 0, 255), MAKE_COLORREF(255, 0, 0),MAKE_COLORREF(0, 255, 0),MAKE_COLORREF(255, 69, 0)};


const int cW = 180/cell;
const int cH = 120/cell;

int num_of_group=0;

void show_help(void)
{
	printf("================================================================\n");
	printf("                        <B L A U I N D>\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("i : camera on & Robot Init\n");
	printf("t : test Robot motion\n");
	printf("s : control the parameters for color fitering (1~=)\n");
	printf("m : make a chained map\n");
	printf("g : group the chains");
	printf("b : active detected chains\n");
	printf("q : exit \n");
	printf("========If you want AI mode, type with a command '-ai'========\n");
}

static int ParseOptions(int argc, char *argv[])
{
    int i = 1;

    if(i < argc && argv[i][0] == '-')
    {
        while(i < argc && argv[i][0] == '-')
        {
            if(i > 1 && argv[i][1] == '-')
            {
                printf("Using basic and custom options together is not supported\n");
                return 0;
            }

            // Get options
            if(!strcmp(argv[i], "-ai")){ AI=TRUE;
            	if(++i < argc) sscanf(argv[i], "%d", &COUNT);}
            else
            {
                printf("%s is not a supported option\n If you want AI mode, type with a command '-ai'\n", argv[i]);
                return 0;
            }

            i++;
        }
    }

    if(i < argc)
    {
         printf("%s is not a supported option\n If you want AI mode, type with a command '-ai'", argv[i]);
        return 0;
    }

    // Check for consistency
    if(i < 2) AI=false;

    return 1;
}

int Init_Robot(void){
	sdataload();//stdRGB.sdata load


	init_console();//console init
	if (uart_open() < 0) return -1;
	uart_config(UART1, 57600, 8, UART_PARNONE, 1);



	if (amazon2_timer_open() < 0) {//timer open & config
		printf("AMAZON2 User Timer Open Error!\n");
        return -1;}
    amazon2_timer_int_disable(USING_TIMER);
    amazon2_timer_stop(USING_TIMER);
    amazon2_timer_count_clear(USING_TIMER);
	

	if (open_graphic() < 0) {
		return -1;
	}

	return 1;
}

void Tdelay(float dist_num){
	int now_num =count_num=amazon2_timer_read_count(USING_TIMER);
	while(now_num - count_num <= dist_num*10)
		now_num = amazon2_timer_read_count(USING_TIMER);
}

void align(U16* fpga_videodata, U8* clrmap,U32* chmap)
{	Line line; int posGood=0,lineGood=0;
	C_r();Tdelay(2);
	direct_camera_display_off();
	do{
		read_fpga_video_data(fpga_videodata);

		coloring(fpga_videodata,clrmap);
		line = mkchain(clrmap,chmap,TRAND);
		flip();

		if(!posGood){
			if(line.pos.y<7) {right(); Tdelay(0.3);}
			else if(line.pos.y>9) {left(); Tdelay(0.3);}
			else posGood=TRUE;
		}
		else{
			if (line.m <-5) {Rturn(); Tdelay(0.3);}
			else if(line.m>-1) {Lturn(); Tdelay(0.3);}
			else lineGood=TRUE;
		}
		//if(Read_Command()==4) break;
	}while(!lineGood);
 	C_c(); Tdelay(2);
 	direct_camera_display_on();
}

void G_align(U16* fpga_videodata, U8* clrmap,U32* chmap)
{
	Line line; int posGood=0,lineGood=0;
	int UD=false;

	direct_camera_display_off();
	do{
		if(!posGood){ if(UD){C_d(); Tdelay(1.5);}
			read_fpga_video_data(fpga_videodata);/////Green Pattern
			coloring(fpga_videodata,clrmap);
			line = mkchain(clrmap,chmap,F4); flip();
			
			if(line.pos.x<17) {sleft(); Tdelay(0.3);}
			else if(line.pos.x>20) {sright(); Tdelay(0.3);}
			else posGood=TRUE;
		}
		else{if(!UD){C_u(); Tdelay(1.5);}
			read_fpga_video_data(fpga_videodata);/////Green Pattern
			coloring(fpga_videodata,clrmap);
			line = mkchain(clrmap,chmap,F3); flip();

			if(line.m<-5) {srturn(); Tdelay(0.3);}
			else if(line.m>-1) {slturn(); Tdelay(0.3);}
			else posGood=TRUE;

			printf("m : %f\n",line.m);
		}
	}while(!lineGood);
 	C_d(); Tdelay(2);
 	direct_camera_display_on();
}


int main(int argc, char *argv[])
{
 	if(!ParseOptions(argc, argv)) return -1;

	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U8* clrmap = (U8*)malloc(180*120);
	U32* chmap = (U32*)malloc(sizeof(U32)*cW*cH);
	Group* group = (Group*)malloc(sizeof(Group)*init_group);
	//int pattern;

	if(Init_Robot()==-1) return -1;



	if(AI){
		int startline=0;

		printf("AUTO MODE\n");
		printf("camera on & Robot Init\n");
		direct_camera_display_on();

		if (amazon2_timer_config(USING_TIMER, 100000) < 0) {
		printf("AMAZON2 User Timer Config Error!\n"); return -1;}

		amazon2_timer_int_enable(USING_TIMER);
		amazon2_timer_run(USING_TIMER);
		printf("Timer %d, Start....\n", USING_TIMER);


		do{
			direct_camera_display_off();
			read_fpga_video_data(fpga_videodata);
			coloring(fpga_videodata,clrmap);
			mkchain(clrmap,chmap,F1); 
			mkGroup(chmap,group);flip();

			if(find_pattern(group,F1)){Tdelay(1); startline=2;}
			else if(startline==2&&!find_pattern(group,F1)) startline=TRUE;
		}while(startline==TRUE);///----------------start line
		init_stand();Tdelay(2); C_c(); Tdelay(2); //STAAAAAAAAAAAART
		direct_camera_display_on();

			/////////////////////////////////////////////////1st stage
			walk(); Tdelay(4);
			align(fpga_videodata,clrmap,chmap);
			Swalk(); Tdelay(4); init_stand();Tdelay(1);  //////swalk signal!??????????
			tuktuk(); Tdelay(2); RedLoad(); Tdelay(30); 
			wakeup();Tdelay(3.5);


			//////////////////////////////////////////////////2nd stage
			walk(); Tdelay(2);
			align(fpga_videodata,clrmap,chmap);
			walk(); Tdelay(2);
			Swalk(); Tdelay(4); init_stand();Tdelay(1);
			tuktuk();  Tdelay(2); hudle();Tdelay(16); C_c();Tdelay(2);


			//////////////////////////////////////////////////3rd stage
			walk(); Tdelay(3); Lturn(); Tdelay(0.5);
			align(fpga_videodata,clrmap,chmap);
			walk(); Tdelay(8);
			align(fpga_videodata,clrmap,chmap);C_d(); Tdelay(2);init_stand();Tdelay(0.8);
			Swalk(); direct_camera_display_off();
			do{
				read_fpga_video_data(fpga_videodata);////////W2BK ver.
				coloring(fpga_videodata,clrmap);
				mkchain(clrmap,chmap,F2); 
				mkGroup(chmap,group);flip();
			}while(!find_pattern(group,F2));
			direct_camera_display_on(); align(fpga_videodata,clrmap,chmap);init_stand();Tdelay(0.8);
			tuktuk();  Tdelay(2); stairUp(); Tdelay(8);
			do{
				G_align(fpga_videodata,clrmap,chmap);
				Swalk(); Tdelay(5);init_stand();Tdelay(0.8);
			}while(!find_pattern(group,F3));
			stairDown();Tdelay(5);
			


	}
	else{
		int loop=1;
		Chain* CHbuff = (Chain*)malloc(sizeof(Chain)*200);

		show_help();
		//||----------------------------configure mode------------------------------||
		do{
			int ch = getchar();
			U32 act;

			switch(ch)
			{
				case 'q': loop = 0; 
				break;// quit

				case 'h':
				show_help();
				break;

				case 'i':
				printf("camera on & Robot Init\n");
				direct_camera_display_on();
				init_stand();
				break;

				case 't':
				printf("t : test Robot motion\n");
				TestItemSelectRobot();
				break;

				case 'm':
				printf("Make Chain up\n");
				read_fpga_video_data(fpga_videodata);
				direct_camera_display_off();
				coloring(fpga_videodata,clrmap);
				mkchain(clrmap,chmap,TEST);
				CHclassfier(CHbuff,  chmap);
				flip();
				break;// flitering videodata to colored image & draw

				case 'g':
				read_fpga_video_data(fpga_videodata);
				direct_camera_display_off();
				coloring(fpga_videodata,clrmap);
				mkchain(clrmap,chmap,F1|F2|F3|F4|F5);
				mkGroup(chmap,group);
				//pattern  = find_pattern(group);
				//printf("pattern is %d",pattern);
				//CHclassfier(CHbuff,  chmap);
				flip();
				break;// flitering videodata to colored image & draw

				case 'b':
				printf("Activate the detected chains\n");
				direct_camera_display_off();
				scanf("%08x",&act);
				coloring(fpga_videodata,clrmap);
				actCH(chmap,act);
				flip();
				break;// flitering videodata to colored image & draw

				case 'o':
				direct_camera_display_off();
				draw_fpga_video_data_full(fpga_videodata);
				flip();
				break;

				case 's':
				direct_camera_display_off();
				standard(fpga_videodata,clrmap);
				break;

				case 'L':
				find_pattern(group, F1|F2|F3|F4|F5);
				break;
				}
		}while(loop);
		free(CHbuff);
	}

	free(fpga_videodata);
	free(clrmap);
	free(chmap);
	free(group);
	

    amazon2_timer_int_disable(USING_TIMER);
    amazon2_timer_stop(USING_TIMER);
    amazon2_timer_count_clear(USING_TIMER);

	printf("Timer %d, End....\n", USING_TIMER);

	amazon2_timer_close();
	close_graphic();
	uart_close();

	return 0;
}


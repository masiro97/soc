#include "BLAU.h"


void init_console(void)
{
    tcgetattr(0, &inittio);
    newtio = inittio;
    newtio.c_lflag &= ~ICANON;
    newtio.c_lflag &= ~ECHO;
    newtio.c_lflag &= ~ISIG;
    newtio.c_cc[VMIN] = 1;
    newtio.c_cc[VTIME] = 0;

    cfsetispeed(&newtio, B115200);

    tcsetattr(0, TCSANOW, &newtio);
}


void PrintBannerRobot(void)
{
   printf("\n");
   printf("================================================================\n");
   printf("              <<<< Robot Body TEST Selection >>>>               \n");
   printf("----------------------------------------------------------------\n");
   printf("  1. init        -[i]      |  2. walk        -[o] \n");
   printf("  3. left walk   -[k]      |  4. right walk  -[;] \n");
   printf("  5. left turn   -[q,a,z]  |  6. right turn  -[e,f,c] \n");
   printf("  7. cam_c       -[w]      |  8. cam_90      -[s]      |  9. cam_m90  -[x]  \n");
   printf("----------------------------------------------------------------\n");
   printf("   19. Quit            -[v]         \n");
   printf("================================================================\n");
   
}


int TestItemSelectRobot(void)
{
   char Item;
    
   while(1) {
       PrintBannerRobot();
      printf("\nSelected Test Item :  ");
       Item = getchar();
      putchar(Item);

      switch(Item) {
         case 'i' : case 'I' :    init_stand();         break;
         case 'o' : 			  walk();         break;
         case 'k' : 			  left();         break;
         case ';' :				  right();            break;      
         case 'q' : case 'Q' :    Lturn();         break;
         case 'a' : case 'A' :    C7();         break;
         case 'z' : case 'Z' :    C8();            break;   
         case 'e' : case 'E' :    Rturn();         break;
         case 'd' : case 'D' :    C10();            break;   
         case 'c' : case 'C' :    C11();            break;
         case 'w' : case 'W' :    C_c();         break;
         case 's' : case 'S' :    C13();            break;   
         case 'x' : case 'X' :    C_r();            break;      
         case 'v' : case 'V' :   return 0;
         default : printf("\nNo Test Item Selected");   break;
      }
   }
   return 0;
}



void DelayLoop(int delay_time)
{
	while(delay_time)
		delay_time--;
}

void Send_Command(unsigned char Ldata, unsigned char Ldata1)
{
	unsigned char Command_Buffer[6] = {0,};

	Command_Buffer[0] = START_CODE;	// Start Byte -> 0xff
	Command_Buffer[1] = START_CODE1; // Start Byte1 -> 0x55
    Command_Buffer[2] = Ldata;
	Command_Buffer[3] = Ldata1;
	Command_Buffer[4] = Hdata;  // 0x00
	Command_Buffer[5] = Hdata1; // 0xff

	uart1_buffer_write(Command_Buffer, 6);
}

unsigned char Read_Command()
{
	unsigned char Command_Buffer[6] = {0,};

	uart1_buffer_read(Command_Buffer, 6);

	return Command_Buffer[2];
}


void init_stand()
{
   Send_Command(0x01, 0xfe);
}

void walk()
{
   Send_Command(0x02, 0xfd);  //
}

void left()
{
   Send_Command(0x04, 0xfb);  //
}
void right()
{
   Send_Command(0x05, 0xfa);  //
}

void Lturn()
{
   Send_Command(0x06, 0xf9);  //
}

void C7()
{
   Send_Command(0x07, 0xf8);  //
}

void C8()
{
   Send_Command(0x08, 0xf7);  //
}

void Rturn()
{
   Send_Command(0x09, 0xf6);  //
}

void C10()
{
   Send_Command(0x0a, 0xf5);  //
}

void C11()
{
   Send_Command(0x0b, 0xf4);  //
}

void C_c()
{
   Send_Command(0x0c, 0xf3);  //
}

void C13()
{
   Send_Command(0x0d, 0xf2);  //
}

void C_r()
{
   Send_Command(0x0e, 0xf1);  //
}


void wakeup()
{
  Send_Command(0x10,0xef);
}

void hudle()
{
  Send_Command(0x11,0xee);
}


void Swalk()
{
  Send_Command(0x12, 0xed);
}


void tuktuk()
{
  Send_Command(0x13,0xec);
}


void RedLoad()
{
  Send_Command(0x14,0xeb);
}

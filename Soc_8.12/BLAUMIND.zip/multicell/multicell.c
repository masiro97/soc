//20160727

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "amazon2_sdk.h"
#include "graphic_api.h"

#define White 0
#define Black 1
#define Yellow 2
#define Blue 3
#define Red 4
#define Green 5
#define Orange 6

S8 SR1[7], SG1[7], SB1[7], SR2[7], SG2[7], SB2[7];

EGL_COLOR Sclr[7] = {MAKE_COLORREF(255, 255, 255),MAKE_COLORREF(80, 80, 80),MAKE_COLORREF(255, 255, 0),
					MAKE_COLORREF(0, 0, 255), MAKE_COLORREF(255, 0, 0),MAKE_COLORREF(255, 69, 0)};



void show_help(void)
{
	printf("================================================================\n");
	printf("MultiColor with Cell\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("a : direct camera display on\n");
	printf("p : Pose Capture \n");
	printf("c : show colored image (o is return)\n");
	printf("s : control the paraeters for color fitering (1~=)\n");
	printf("q : exit \n");
	printf("================================================================\n");
}

void coloring(U16* img)
{
	int i,j,c,clast=0,cell=6, thhold=22;
	U8 R,G,B;

	draw_rectfill(0,0, 320, 480, MAKE_COLORREF(0, 0, 0));

	for(i=0;i<120/cell;i++)
		for(j=0;j<180/cell;j++)
		{
			int a,b,last=0;
			int V[7]={0,0,0,0,0,0,0};

			for(a=0;a<cell;a++)
				for(b=0;b<cell;b++)
				{
					EXTRACT_RGB565(img[(i*180 + j)*cell + a*180+b],R,G,B);
					c=last;
					while(1){
						if((SR1[c]<=R&&R<=SR2[c]) && (SG1[c]<=G&&G<=SG2[c]) && (SB1[c]<=B&&B<=SB2[c])) 
							{ last =c; V[c]++; break;}

						c++; if(c==last) break; 
						if(c>6) c=0;
					}
				}

			c=clast;
			while(1){
				if(V[c]>thhold) 
					{clast = c; draw_rectfill(320-(i+1)*16, j*16, 16, 16, Sclr[c]); break;}
				
				c++; if(c==clast) break;
				if(c>6) c=0;
			}
	}
}

void standard(U16* fpga_videodata)
{
	int sloop=1;
	printf("what color\n");
	int c = getchar();

	do{
		int sch = getchar();

		switch(sch)
		{
			case 'Q':
			case 'q': sloop = 0; 
			break;// quit

			case '1':
			if(0<SR1[c]) SR1[c]--; 
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c],c);
			coloring(fpga_videodata);
			flip();
			break;

			case '2':
			if(SR1[c]<31) SR1[c]++;
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '3':
			if(0<SG1[c]) SG1[c]--; 
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '4':
			if(SG1[c]<63) SG1[c]++; 
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '5':
			if(0<SB1[c]) SB1[c]--;
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '6':
			if(SB1[c]<31) SB1[c]++;
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '7':
			if(0<SR2[c]) SR2[c]--;
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '8':
			if(SR2[c]<31) SR2[c]++;
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '9':
			if(0<SG2[c]) SG2[c]--; 
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '0':
			if(SG2[c]<63) SG2[c]++; 
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '-':
			if(0<SB2[c]) SB2[c]--; 
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;

			case '=':
			if(SB2[c]<31) SB2[c]++; 
			printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
			coloring(fpga_videodata);
			flip();
			break;
		}
	}while(sloop);
}


int main(void)
{
	int loop=1;
	
	FILE* sfile = fopen("./stdRGB.sdata","rb");
	printf("1");
	if(sfile!=NULL){
		printf("2");

		fread(SR1,sizeof(U8),7,sfile);
		fread(SG1,sizeof(U8),7,sfile+7);
		fread(SB1,sizeof(U8),7,sfile+14);
		fread(SR2,sizeof(U8),7,sfile+21);
		fread(SG2,sizeof(U8),7,sfile+28);
		fread(SB2,sizeof(U8),7,sfile+35);


	}
	else{
		printf("3");
		int i;
		for(i=0;i<7;i++) SR1[i] = 0;
		for(i=0;i<7;i++) SG1[i] = 0;
		for(i=0;i<7;i++) SB1[i] = 0;
		for(i=0;i<7;i++) SR2[i] = 31;
		for(i=0;i<7;i++) SG2[i] = 63; 
		for(i=0;i<7;i++) SB2[i] = 31;
	}
	printf("4");
	fclose(sfile);
	
	U16* fpga_videodata = (U16*)malloc(180 * 120*2);


	if (open_graphic() < 0) {
		return -1;
	}

	show_help();
	
	do{
		int ch = getchar();

		switch(ch)
		{
			case 'Q':
			case 'q': loop = 0; 
			sfile = fopen("./stdRGB.sdata","wb");
			fwrite(SR1,sizeof(U8),7,sfile);
			fwrite(SG1,sizeof(U8),7,sfile+7);
			fwrite(SB1,sizeof(U8),7,sfile+14);
			fwrite(SR2,sizeof(U8),7,sfile+21);
			fwrite(SG2,sizeof(U8),7,sfile+28);
			fwrite(SB2,sizeof(U8),7,sfile+35);
			fclose(sfile);
			break;// quit

			case 'H':
			case 'h':
			show_help();
			break;

			case 'A':
			case 'a':
			printf("direct camera display on\n");
			direct_camera_display_on();
			break;

			case 'P':
			case 'p':
			printf("Now fpga video data\n");
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;//fpga image read & draw the image

			case 'C':
			case 'c':
			printf("Colored Image\n");
			direct_camera_display_off();
			coloring(fpga_videodata);
			flip();
			break;// flitering videodata to colored image & draw

			case 'O':
			case 'o':
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;

			case 'S':
			case 's':
			direct_camera_display_off();
			standard(fpga_videodata);
			break;
			}

	}while(loop);


	free(fpga_videodata);
	close_graphic();

	return 0;
}


//20160727

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <fcntl.h>
#include <unistd.h>
#include <string.h>	


#include <sys/ioctl.h>
#include "amazon2_sdk.h"
#include "graphic_api.h"

#define cell 6

#define White 0
#define Black 1
#define Yellow 2
#define Blue 3
#define Red 4
#define Green 5
#define Orange 6

//non 0
#define W2BK 2
#define BK2Y 4
#define W2B 8

U8 SR1[7], SG1[7], SB1[7], SR2[7], SG2[7], SB2[7];

EGL_COLOR Sclr[7] = {MAKE_COLORREF(255, 255, 255),MAKE_COLORREF(50, 50, 50),MAKE_COLORREF(255, 255, 0),
		MAKE_COLORREF(0, 0, 255), MAKE_COLORREF(255, 0, 0),MAKE_COLORREF(0, 255, 0),MAKE_COLORREF(255, 69, 0)};



void show_help(void)
{
	printf("================================================================\n");
	printf("Make Chain\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("a : direct camera display on\n");
	printf("p : Pose Capture \n");
	printf("c : show colored image (o is return)\n");
	printf("s : control the paraeters for color fitering (1~=)\n");
	printf("m : make a chained map\n");
	printf("q : exit \n");
	printf("================================================================\n");
}

void std_help(int c)
{
	printf("===================\n");
	printf("Color : %d \n",c);
	printf("===================\n");
	printf("White 0\n");
	printf("Black 1\n");
	printf("Yellow 2\n");
	printf("Blue 3\n");
	printf("Red 4\n");
	printf("Green 5\n");
	printf("Orange 6 \n");
	printf("===================\n");
}

void coloring(U16* img, U8* clrmap)
{
	int i,j,c,clast=0, thhold=22;
	U8 R,G,B;

	draw_rectfill(0,0, 320, 480, MAKE_COLORREF(0, 0, 0));

	for(i=0;i<120/cell;i++)
		for(j=0;j<180/cell;j++)
		{
			int a,b,last=0;
			int V[7]={0,0,0,0,0,0,0};

			for(a=0;a<cell;a++)
				for(b=0;b<cell;b++)
				{
					EXTRACT_RGB565(img[(i*180 + j)*cell + a*180+b],R,G,B);
					c=last;
					while(1){
						if((SR1[c]<=R&&R<=SR2[c]) && (SG1[c]<=G&&G<=SG2[c]) && (SB1[c]<=B&&B<=SB2[c])) 
							{ last =c; V[c]++; break;}

						c++; if(c>6) c=0;
						if(c==last) break; 
					}
				}

			c=clast;
			while(1){
				if(V[c]>thhold) 
					{clast=clrmap[i*(180/cell)+j]= c; draw_rectfill(320-(i+1)*16, j*16, 16, 16, Sclr[c]); break;}
				
				c++; if(c>6) c=0;
				if(c==clast) break;
			}
	}
}

void chainup(U8 from, U8 to, U8* chmap, int dir,int i,int j)
{
	if(from==White){ if(to==Black) chmap[(i)*(180/cell)+j] += (W2BK)<<(4*dir); 
					 if(to==Blue) chmap[(i)*(180/cell)+j] += (W2B)<<(4*dir);}
	else if(from==Black){if(to==White) chmap[(i)*(180/cell)+j] += (W2BK)<<(4*dir);
						 if(to==Yellow) chmap[(i)*(180/cell)+j]+= (BK2Y)<<(4*dir);}
	else if(from==Blue&&to==White) chmap[(i)*(180/cell)+j]+= (W2B)<<(4*dir);
	else if(from==Yellow&&to==Black) chmap[(i)*(180/cell)+j]+= (BK2Y)<<(4*dir);
}

void mkchain(U8* clrmap, int* chmap)
{
	int i, j;
	for(i=0;i<120/cell;i++)
		for(j=0;j<180/cell;j++)
		{
			int dir; U8 to;
			U8 from = clrmap[(i)*(180/cell)+j];
			chmap[(i)*(180/cell)+j] = 0x00000000;

			if(!(from==Red)||(from==Green)||(from==Orange))
			for(dir=0;dir<8;dir++)
			switch(dir)
			{
				case 0: if((0<=(i-1)&&(i-1)<(120/cell)) || (0<=j&&j<180/cell))
						{	to = clrmap[(i-1)*(180/cell)+j]; chainup(from,to,chmap,dir,i,j);} break;
				case 1: if((0<=(i-1)&&(i-1)<120/cell) || (0<=(j+1)&&(j+1)<180/cell))
						{	to = clrmap[(i-1)*(180/cell)+j+1]; chainup(from,to,chmap,dir,i,j);}	break;
				case 2: if((0<=(i)&&(i)<120/cell) || (0<=(j+1)&&(j+1)<180/cell))
						{	to = clrmap[(i)*(180/cell)+j+1]; chainup(from,to,chmap,dir,i,j);} break;
				case 3: if((0<=(i+1)&&(i+1)<120/cell) || (0<=(j+1)&&(j+1)<180/cell))
						{	to = clrmap[(i+1)*(180/cell)+j+1]; chainup(from,to,chmap,dir,i,j);} break;
				case 4: if((0<=(i+1)&&(i+1)<120/cell) || (0<=(j)&&(j)<180/cell))
						{	to = clrmap[(i+1)*(180/cell)+j];	chainup(from,to,chmap,dir,i,j);} break;
				case 5: if((0<=(i+1)&&(i+1)<120/cell) || (0<=(j-1)&&(j-1)<180/cell))
						{	to = clrmap[(i+1)*(180/cell)+j-1]; chainup(from,to,chmap,dir,i,j);} break;
				case 6: if((0<=i&&i<(120/cell)) || (0<=(j-1)&&(j-1)<(180/cell)))
						{	to = clrmap[(i)*(180/cell)+j-1];	chainup(from,to,chmap,dir,i,j);} break;
				default: if((0<=(i-1)&&(i-1)<120/cell) || (0<=(j+1)&&(j+1)<180/cell))
						{	to = clrmap[(i-1)*(180/cell)+j-1]; chainup(from,to,chmap,dir,i,j);}
			}
		}
}

void standard(U16* fpga_videodata, U8* clrmap)
{
   int sloop=1;
   
   int c;
   printf("plaase input c");
   scanf("%d",&c);

   do{
      int sch = getchar();

      switch(sch)
      {   
         case 'Q':
         case 'q': sloop = 0; 
         break;// quit

         case 'H':
	 	 case 'h':
		 std_help(c);
		 break;

         case '1':
         if(0<SR1[c]) SR1[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '2':
         if(SR1[c]<31) SR1[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '3':
         if(0<SG1[c]) SG1[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '4':
         if(SG1[c]<63) SG1[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '5':
         if(0<SB1[c]) SB1[c]--;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '6':
         if(SB1[c]<31) SB1[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '7':
         if(0<SR2[c]) SR2[c]--;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '8':
         if(SR2[c]<31) SR2[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '9':
         if(0<SG2[c]) SG2[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '0':
         if(SG2[c]<63) SG2[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '-':
         if(0<SB2[c]) SB2[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '=':
         if(SB2[c]<31) SB2[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case 'w':
         case 'W':
         printf("what color\n");
         scanf("%d",&c);
      }
   }while(sloop);
}

int main(void)
{
	int loop=1;

	int filedes;
	U8 buff[7*6];
    FILE *sfile;

    filedes = open( "stdRGB.sdata", O_RDONLY );

	 if( filedes != -1 ) {
        sfile = fdopen( filedes , "r" );
        if( sfile != NULL ) {
        	fread(buff,1,7*6,sfile);
        	memcpy(SR1,buff,7);
        	memcpy(SG1,&buff[7],7);
        	memcpy(SB1,&buff[14],7);
        	memcpy(SR2,&buff[21],7);
        	memcpy(SG2,&buff[28],7);
        	memcpy(SB2,&buff[35],7);
            fclose( sfile );
        }
    }
    else{
		int i;
		for(i=0;i<7;i++) SR1[i] = 0;
		for(i=0;i<7;i++) SG1[i] = 0;
		for(i=0;i<7;i++) SB1[i] = 0;
		for(i=0;i<7;i++) SR2[i] = 31;
		for(i=0;i<7;i++) SG2[i] = 63; 
		for(i=0;i<7;i++) SB2[i] = 31;
	}
	
	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U8* clrmap = (U8*)malloc(180*120);
	int* chmap = (U8*)malloc(180*120);

	if (open_graphic() < 0) {
		return -1;
	}

	show_help();
	
	do{
		int ch = getchar();

		switch(ch)
		{
			case 'Q':
			case 'q': loop = 0; 
			filedes = open( "stdRGB.sdata",O_WRONLY|O_CREAT,0644 );

			if( filedes != -1 ) {
	     	   sfile = fdopen( filedes , "w" );
    	 	   if( sfile != NULL ) {
    	 	   		memcpy(buff,SR1,7);
		        	memcpy(buff+7,SG1,7);
		        	memcpy(buff+14,SB1,7);
		        	memcpy(buff+21,SR2,7);
		        	memcpy(buff+28,SG2,7);
		        	memcpy(buff+35,SB2,7);
		        	fwrite(buff,1,7*6,sfile);
		            fclose( sfile );
		        }
		    }
			break;// quit

			case 'H':
			case 'h':
			show_help();
			break;

			case 'A':
			case 'a':
			printf("direct camera display on\n");
			direct_camera_display_on();
			break;

			case 'P':
			case 'p':
			printf("Now fpga video data\n");
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;//fpga image read & draw the image

			case 'C':
			case 'c':
			printf("Colored Image\n");
			direct_camera_display_off();
			coloring(fpga_videodata,clrmap);
			flip();
			break;// flitering videodata to colored image & draw

			case 'M':
			case 'm':
			printf("Colored Image\n");
			direct_camera_display_off();
			coloring(fpga_videodata,clrmap);
			mkchain(clrmap,chmap);
			flip();
			break;// flitering videodata to colored image & draw

			case 'O':
			case 'o':
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;

			case 'S':
			case 's':
			direct_camera_display_off();
			standard(fpga_videodata,clrmap);
			break;
			}

	}while(loop);


	free(fpga_videodata);
	close_graphic();

	return 0;
}


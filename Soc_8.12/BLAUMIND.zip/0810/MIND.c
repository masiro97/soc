#include "MIND.h"
#include <stdlib.h>


void sdataload()
{
	int filedes;
	U8 buff[7*6];
    FILE *sfile;

    filedes = open( "stdRGB.sdata", O_RDONLY );

	 if( filedes != -1 ) {
        sfile = fdopen( filedes , "r" );
        if( sfile != NULL ) {
        	fread(buff,1,7*6,sfile);
        	memcpy(SR1,buff,7);
        	memcpy(SG1,&buff[7],7);
        	memcpy(SB1,&buff[14],7);
        	memcpy(SR2,&buff[21],7);
        	memcpy(SG2,&buff[28],7);
        	memcpy(SB2,&buff[35],7);
            fclose( sfile );
        }
    }
    else{
		int i;
		for(i=0;i<7;i++) SR1[i] = 0;
		for(i=0;i<7;i++) SG1[i] = 0;
		for(i=0;i<7;i++) SB1[i] = 0;
		for(i=0;i<7;i++) SR2[i] = 31;
		for(i=0;i<7;i++) SG2[i] = 63; 
		for(i=0;i<7;i++) SB2[i] = 31;
	}
}

void sdatawrite()
{
	int filedes;
	U8 buff[7*6];
	FILE *sfile;

	filedes = open( "stdRGB.sdata",O_WRONLY|O_CREAT,0644 );

		if( filedes != -1 ) {
     	   sfile = fdopen( filedes , "w" );
	 	   if( sfile != NULL ) {
	 	   		memcpy(buff,SR1,7);
	        	memcpy(buff+7,SG1,7);
	        	memcpy(buff+14,SB1,7);
	        	memcpy(buff+21,SR2,7);
	        	memcpy(buff+28,SG2,7);
	        	memcpy(buff+35,SB2,7);
	        	fwrite(buff,1,7*6,sfile);
	            fclose( sfile );
	        }
	    }
}

void CHwrite(Chain* CHbuff, int bufN)
{
	int filedes; char buf[1024*5];
	char fileName[50];
	FILE *sfile;

	sprintf(fileName, "CH.txt");
	filedes = open( fileName,O_WRONLY|O_CREAT,0644 );

		if( filedes != -1 ) {
     	   sfile = fdopen( filedes , "w" );
	 	   if( sfile != NULL ) {
	 	   		int z,x,len;

	 	   		len = sprintf(buf,"-------Chains Histogram(%d)--------\n",bufN);

	 	   		for(z=0;z<bufN;z++)
	 	   		{
	 	   			len += sprintf(buf+len,"%2d. %08X --- ",z+1,CHbuff[z].ch);
	 	   			for(x=0;x<CHbuff[z].score;x++) len += sprintf(buf+len,"1");
	 	   			len += sprintf(buf+len,"\n");
	 	   		}

	 	   		fwrite(buf,1,len,sfile);
	            fclose( sfile );
	        }
	    }
}


void coloring(U16* img, U8* clrmap)
{
	int i,j,c,clast=0, thhold=10;
	U8 R,G,B;

	draw_rectfill(0,0, 320, 480, MAKE_COLORREF(0, 0, 0));

	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		{
			int a,b,last=0;
			int V[7]={0,0,0,0,0,0,0};

			for(a=0;a<cell;a++)
				for(b=0;b<cell;b++)
				{
					EXTRACT_RGB565(img[(i*180 + j)*cell + a*180+b],R,G,B);
					c=last;
					while(1){
						if((SR1[c]<=R&&R<=SR2[c]) && (SG1[c]<=G&&G<=SG2[c]) && (SB1[c]<=B&&B<=SB2[c])) 
							{ last =c; V[c]++; break;}

						c++; if(c>6) c=0;
						if(c==last) break; 
					}
				}

			c=clast;
			while(1){
				if(V[c]>thhold) 
					{clast=clrmap[i*cW+j]= c;  draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, Sclr[c]); break;}
				
				c++; if(c>6) c=0;
				if(c==clast) {clast=0; clrmap[i*cW+j]= NN; break;}
			}
	}
}

void chainup(U8 from, U8 to, U32* chmap, int dir,int i,int j)
{
	int pix = (i)*cW+j;

	if(from==White){ if(to==Black) chmap[pix] += (W2BK)<<(4*dir); 
					 if(to==Blue) chmap[pix] += (W2B)<<(4*dir); }
	else if(from==Black){if(to==White) chmap[pix] += (W2BK)<<(4*dir);
						 if(to==Yellow) chmap[pix]+= (BK2Y)<<(4*dir);}
	else if(from==Blue&&to==White) chmap[pix]+= (W2B)<<(4*dir);
	else if(from==Yellow&&to==Black) chmap[pix]+= (BK2Y)<<(4*dir);
}

int W2BK_Ver(U32 CH)//W2BK Vertical
{
	if(CH==0x22200000) return TRUE;//egu
	if(CH==0x00002220) return TRUE;//jugu
	if(CH==0x22000000) return TRUE;//dol1
	if(CH==0x00002200) return TRUE;//dolban
	if(CH==0x00022220) return TRUE;//dol2
	if(CH==0x22200002) return TRUE;//dol2ban

	return false;
}
int W2BK_Hor(U32 CH)//W2BK Horizontal
{
	if(CH==0x00222000) return TRUE;
	if(CH==0x20000022) return TRUE;
	if(CH==0x02222000) return TRUE;
	if(CH==0x20000222) return TRUE;

	return false;
}
int StrtP(U32 CH)//Start pattern
{
	if(CH==0x44400000) return TRUE;
	if(CH==0x00004440) return TRUE;

	return false;
}
int EdP(U32 CH)//End pattern
{
	if(CH==0x40444044) return TRUE;
	if(CH==0x40000044) return TRUE;

	return false;
}

int GrP(U8 Clr)//Green
{
	if(Clr==Green) return TRUE;

	return false;
}


int Ft4Trend(U32 CH) //trandline
{
	if(!W2BK_Ver(CH)){
		if((CH&0x000FF000) == 0x00022000) return TRUE;
		if((CH&0x0000FF00) == 0x00002200) return TRUE;
		if((CH&0xFF000000) == 0x22000000) return TRUE;
		if((CH&0xF000000F) == 0x20000002) return TRUE;
	}
	return false;
}

Line mkchain(U8* clrmap, U32* chmap, U8 mode)
{
	Line line;
	int i, j;  EGL_POINT pos[800]; int Pn=0;

	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		{
			int dir; U8 to;
			U8 from = clrmap[(i)*cW+j];
			chmap[(i)*cW+j] = 0x00000000;

			if(!((from==Red)||(from==Green)||(from==Orange)||(from==NN)))
			for(dir=0;dir<8;dir++)
			switch(dir)
			{
				case 0: if((0<=(i-1)&&(i-1)<cH) && (0<=j&&j<cW))
						{	to = clrmap[(i-1)*cW+j]; chainup(from,to,chmap,dir,i,j);} break;
				case 1: if((0<=(i-1)&&(i-1)<cH) && (0<=(j+1)&&(j+1)<cW))
						{	to = clrmap[(i-1)*cW+j+1]; chainup(from,to,chmap,dir,i,j);}	break;
				case 2: if((0<=(i)&&(i)<cH) && (0<=(j+1)&&(j+1)<cW))
						{	to = clrmap[(i)*cW+j+1]; chainup(from,to,chmap,dir,i,j);} break;
				case 3: if((0<=(i+1)&&(i+1)<cH) && (0<=(j+1)&&(j+1)<cW))
						{	to = clrmap[(i+1)*cW+j+1]; chainup(from,to,chmap,dir,i,j);} break;
				case 4: if((0<=(i+1)&&(i+1)<cH) && (0<=(j)&&(j)<cW))
						{	to = clrmap[(i+1)*cW+j];	chainup(from,to,chmap,dir,i,j);} break;
				case 5: if((0<=(i+1)&&(i+1)<cH) && (0<=(j-1)&&(j-1)<cW))
						{	to = clrmap[(i+1)*cW+j-1]; chainup(from,to,chmap,dir,i,j);} break;
				case 6: if((0<=i&&i<cH) && (0<=(j-1)&&(j-1)<cW))
						{	to = clrmap[(i)*cW+j-1];	chainup(from,to,chmap,dir,i,j);} break;
				default: if((0<=(i-1)&&(i-1)<cH) && (0<=(j-1)&&(j-1)<cW))
						{	to = clrmap[(i-1)*cW+j-1]; chainup(from,to,chmap,dir,i,j);}
			}

			if(mode!=TEST && chmap[(i)*cW+j] != 0x00000000){
				if((mode==TRAND)&&Ft4Trend(chmap[i*cW+j])){
					pos[Pn].x=j; pos[Pn++].y=i;
					draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, MAKE_COLORREF(255,0,115));
				}
				else
				{	
					if((mode&F1)==F1&&StrtP(chmap[i*cW+j])){chmap[(i)*cW+j] = 		0;
						draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, MAKE_COLORREF(0,255,166));}
					else if((mode&F2)==F2&& W2BK_Ver(chmap[i*cW+j])) {chmap[i*cW+j]=1;
						draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, MAKE_COLORREF(0,220,130));}
					else if((mode&F3)==F3&& W2BK_Hor(chmap[i*cW+j])) {chmap[i*cW+j]=2; pos[Pn].x=j; pos[Pn++].y=i;
						draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, MAKE_COLORREF(50,155,200));}
					else if((mode&F5)==F5&& EdP(chmap[i*cW+j])) {chmap[i*cW+j]=		4;
						draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, MAKE_COLORREF(100,45,150));}
					else chmap[(i)*cW+j] = 0xFFFFFFFF;
				}
			}
			else{
				if((mode&F4)==F4&& GrP(from)) {chmap[i*cW+j]=	3;  pos[Pn].x=j; pos[Pn++].y=i;}
				else chmap[(i)*cW+j] = 0xFFFFFFFF;
			} 
			
		}

		if(mode==TRAND || (mode&F4) || (mode&F3) && Pn>15) line= TrendLine(pos,Pn);

		return line;
}

void actCH(U32* chmap,U32 act)
{
	int i, j;
	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		{
			if(act==chmap[i*cW+j]) draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, MAKE_COLORREF(0,255,166));
		}
}

int qcmp(const void *first, const void *second)
{
	Chain c1 = *(Chain*)first;
	Chain c2 = *(Chain*)second;

	if(c1.score > c2.score) return -1;
	else if(c1.score==c2.score) return  0;
	else return 1;
}

void CHclassfier(Chain* CHbuff, U32* chmap)
{
	int bufN=0;

	int i, j;
	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		{
			if(chmap[i*cW+j]!= 0xFFFFFFFF){
				if(bufN!=0)
				{
					int a;
					for(a=0;a<bufN;a++)
					if(CHbuff[a].ch==chmap[i*cW+j]) break;

					if(a==bufN){
					CHbuff[bufN].ch = chmap[i*cW+j];
					CHbuff[bufN++].score = 1;}
					else CHbuff[a].score++;
				}
				else
				{	CHbuff[bufN].ch = chmap[i*cW+j];
					CHbuff[bufN++].score=1;		}
			}
		}

	qsort((void*)CHbuff,bufN,sizeof(Chain),qcmp);

	CHwrite(CHbuff,bufN);
}

#define R2D 180/3.14
Line TrendLine(EGL_POINT* pos, int Pn)
{
	Line line;
   int i, b1,b2; float m;
   int sx = 0, sy =0, sxy = 0, sx2 = 0, sy2 = 0;
   for(i=0;i<Pn;i++)
   {
		sx += pos[i].x;
		sy += pos[i].y;
		sxy += (pos[i].x)*(pos[i].y);
		sx2 += (pos[i].x)*(pos[i].x);
		sy2 += (pos[i].y)*(pos[i].y);
   }
   b1 = Pn*sxy - sx*sy;
   b2 = Pn*sx2 - sx*sx;

   m = -R2D*atan2(b1,b2); line.m=m; line.pos.x=sx/Pn; line.pos.y=sy/Pn;

   //printf("TrendLine is %.2f degree\n point(%d,%d), Pn = %d\n", m,sx/Pn,sy/Pn, Pn);
   return line;
}

void std_help(int c)
{
	printf("===================\n");
	printf("Color : %d \n",c);
	printf("===================\n");
	printf("White 0\n");
	printf("Black 1\n");
	printf("Yellow 2\n");
	printf("Blue 3\n");
	printf("Red 4\n");
	printf("Green 5\n");
	printf("Orange 6 \n");
	printf("===================\n");
}

void standard(U16* fpga_videodata, U8* clrmap)
{
   int sloop=1;
   
   int c;
   printf("please input c");
   scanf("%d",&c); printf("%d",c);

   do{
      int sch = getchar();

      switch(sch)
      {   
         case 'Q':
         case 'q': sloop = 0; 
         sdatawrite();
         break;// quit

         case 'H':
	 	 case 'h':
		 std_help(c);
		 break;

         case '1':
         if(0<SR1[c]) SR1[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '2':
         if(SR1[c]<31) SR1[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '3':
         if(0<SG1[c]) SG1[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '4':
         if(SG1[c]<63) SG1[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '5':
         if(0<SB1[c]) SB1[c]--;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '6':
         if(SB1[c]<31) SB1[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '7':
         if(0<SR2[c]) SR2[c]--;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '8':
         if(SR2[c]<31) SR2[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '9':
         if(0<SG2[c]) SG2[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '0':
         if(SG2[c]<63) SG2[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '-':
         if(0<SB2[c]) SB2[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '=':
         if(SB2[c]<31) SB2[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case 'w':
         case 'W':
         printf("what color\n");
         scanf("%d",&c);printf("%d",c);
      }
   }while(sloop);
}

void draw_gpmap(int i, int j,int id, int feature, Group* Gp, U8* gpmap) 
{
   Gp->index = id;
   Gp->ft[feature]++;
   Gp->Csum.x = j; Gp->Csum.y = i;
 //  if(Gp->minX>j) Gp->minX=j; if(Gp->maxX<i) Gp->maxX=i;

   if ((0<=i&&i<cH) && (0<=j&&j<cW) && gpmap[i*cW+j] == 0) gpmap[i*cW + j] = id;
   if ((0<=(i+1)&&(i+1)<cH) && (0<=j&&j<cW) && gpmap[(i+1)*cW+j]==0) gpmap[(i+1)*cW + j] = id;
   if ((0<=(i-1)&&(i-1)<cH) && (0<=j&&j<cW) && gpmap[(i-1)*cW+j]==0) gpmap[(i-1)*cW + j] = id;
   if ((0<=i&&i<cH) && (0<=(j-1)&&(j-1)<cW) && gpmap[i*cW+(j-1)] == 0) gpmap[i*cW+(j-1)] = id;
   if ((0<=i&&i<cH) && (0<=(j+1)&&(j+1)<cW) && gpmap[i*cW+(j+1)] == 0) gpmap[i*cW+(j+1)] = id;
   if ((0<=(i+1)&&(i+1)<cH) && (0<=(j-1)&&(j-1)<cW) && gpmap[(i+1)*cW+(j-1)]==0) gpmap[(i+1)*cW+(j-1)] = id;
   if ((0<=(i+1)&&(i+1)<cH) && (0<=(j+1)&&(j+1)<cW) && gpmap[(i+1)*cW+(j+1)]==0) gpmap[(i+1)*cW+(j+1)] = id;
   if ((0<=(i-1)&&(i-1)<cH) && (0<=(j+1)&&(j+1)<cW) && gpmap[(i-1)*cW+j+1]==0) gpmap[(i-1)*cW+j+1] = id;
   if ((0<=(i-1)&&(i-1)<cH) && (0<=(j-1)&&(j-1)<cW) && gpmap[(i-1)*cW+j-1]==0) gpmap[(i-1)*cW+j-1] = id;
}

void Grouping(int i, int  j, int feature, Group* Gp,U8* gpmap)
{ 
	int index = gpmap[i*cW + j];  

	if (num_of_group == 0) {
		draw_gpmap(i, j, 1, feature, &Gp[num_of_group],gpmap);
		Gp[num_of_group].num_of_point++;
		num_of_group++;
	}
	else {
		if (index == 0) {
			draw_gpmap(i, j, (num_of_group+1), feature, &Gp[num_of_group], gpmap);
			Gp[num_of_group].num_of_point++; num_of_group++; 
		}
		else {
			draw_gpmap(i, j, index, feature, &Gp[index-1], gpmap);
			Gp[index - 1].num_of_point++;
		}
	}
}

void g_Init(Group* gp) 
{
   	int i,n;
	for(i=0; i<init_group;i++){
	   gp[i].num_of_point = 0; gp[i].index=0; gp[i].Csum.x=0;gp[i].Csum.y=0; //gp[i].minX=100;gp[i].maxX=0;
	   for (n = 0; n< num_of_feature;n++)  gp[i].ft[n] = 0;
	}
}

void mkGroup(U32* chmap, Group* group)
{
	int i, j;
	U8* gpmap = (U8*)malloc(cW*cH); for(i=0; i<cW*cH;i++) gpmap[i]=0;

	g_Init(group);
	
	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		switch(chmap[i*cW+j]){
			case 0: Grouping(i,j,0,group,gpmap);break;
			case 1: Grouping(i,j,1,group,gpmap);break;
			case 2: Grouping(i,j,2,group,gpmap);break;
			case 3: Grouping(i,j,3,group,gpmap);break;
			case 4: Grouping(i,j,4,group,gpmap);
		}
	free(gpmap);
}

int max_feature(Group* Gp) {

   int  i,f=0;
   int max = Gp->ft[0];

   // for(i=0;i<5;i++)
   // 	printf("Gp.ft[%d] : %d\n",i,Gp->ft[i]);

   for (i = 0; i < 5;i++) 
   	if(max < Gp->ft[i]) max = Gp->ft[i];

   for(i=0;i<5;i++)
   	if(Gp->ft[i] == max) f=i;

   return f;
}

int find_pattern(Group* Gp, U8 mode)
{
	int k;
	if((mode&F1)||(mode&F2)){
		int checksum=0;

		for(k=0; k<num_of_group;k++)
		if(Gp[k].num_of_point >= GThreshold) checksum+=Gp[k].num_of_point;

		if(mode==F1&&checksum >= 4) return TRUE;
		else if(mode==F2&&checksum>=40&&num_of_group>=4) return TRUE;
		else return false;
	}
	else if(mode&F3)
	{
		int gnum=0;
		for(k=0; k<num_of_group;k++)
			if(Gp[k].ft[2] >= 25) gnum++;

		if(gnum>=2) return TRUE;
	}
	//else if(mode&F5)

	//for(k=0;k<num_of_group;k++)
	//	printf("feature[%d] = %d\n",k,feature[k]);
	return false;
}
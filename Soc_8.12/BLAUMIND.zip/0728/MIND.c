#include "MIND.h"
#include <stdlib.h>


void sdataload()
{
	int filedes;
	U8 buff[7*6];
    FILE *sfile;

    filedes = open( "stdRGB.sdata", O_RDONLY );

	 if( filedes != -1 ) {
        sfile = fdopen( filedes , "r" );
        if( sfile != NULL ) {
        	fread(buff,1,7*6,sfile);
        	memcpy(SR1,buff,7);
        	memcpy(SG1,&buff[7],7);
        	memcpy(SB1,&buff[14],7);
        	memcpy(SR2,&buff[21],7);
        	memcpy(SG2,&buff[28],7);
        	memcpy(SB2,&buff[35],7);
            fclose( sfile );
        }
    }
    else{
		int i;
		for(i=0;i<7;i++) SR1[i] = 0;
		for(i=0;i<7;i++) SG1[i] = 0;
		for(i=0;i<7;i++) SB1[i] = 0;
		for(i=0;i<7;i++) SR2[i] = 31;
		for(i=0;i<7;i++) SG2[i] = 63; 
		for(i=0;i<7;i++) SB2[i] = 31;
	}
}

void sdatawrite()
{
	int filedes;
	U8 buff[7*6];
	FILE *sfile;

	filedes = open( "stdRGB.sdata",O_WRONLY|O_CREAT,0644 );

		if( filedes != -1 ) {
     	   sfile = fdopen( filedes , "w" );
	 	   if( sfile != NULL ) {
	 	   		memcpy(buff,SR1,7);
	        	memcpy(buff+7,SG1,7);
	        	memcpy(buff+14,SB1,7);
	        	memcpy(buff+21,SR2,7);
	        	memcpy(buff+28,SG2,7);
	        	memcpy(buff+35,SB2,7);
	        	fwrite(buff,1,7*6,sfile);
	            fclose( sfile );
	        }
	    }
}

void CHwrite(Chain* CHbuff, int bufN)
{
	int filedes; char buf[1024*5];
	char fileName[50];
	FILE *sfile;

	sprintf(fileName, "CH.txt");
	filedes = open( fileName,O_WRONLY|O_CREAT,0644 );

		if( filedes != -1 ) {
     	   sfile = fdopen( filedes , "w" );
	 	   if( sfile != NULL ) {
	 	   		int z,x,len;

	 	   		len = sprintf(buf,"-------Chains Histogram(%d)--------\n",bufN);

	 	   		for(z=0;z<bufN;z++)
	 	   		{
	 	   			len += sprintf(buf+len,"%2d. %08X --- ",z+1,CHbuff[z].ch);
	 	   			for(x=0;x<CHbuff[z].score;x++) len += sprintf(buf+len,"1");
	 	   			len += sprintf(buf+len,"\n");
	 	   		}

	 	   		fwrite(buf,1,len,sfile);
	            fclose( sfile );
	        }
	    }
}


void coloring(U16* img, U8* clrmap)
{
	int i,j,c,clast=0, thhold=10;
	U8 R,G,B;

	draw_rectfill(0,0, 320, 480, MAKE_COLORREF(0, 0, 0));

	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		{
			int a,b,last=0;
			int V[7]={0,0,0,0,0,0,0};

			for(a=0;a<cell;a++)
				for(b=0;b<cell;b++)
				{
					EXTRACT_RGB565(img[(i*180 + j)*cell + a*180+b],R,G,B);
					c=last;
					while(1){
						if((SR1[c]<=R&&R<=SR2[c]) && (SG1[c]<=G&&G<=SG2[c]) && (SB1[c]<=B&&B<=SB2[c])) 
							{ last =c; V[c]++; break;}

						c++; if(c>6) c=0;
						if(c==last) break; 
					}
				}

			c=clast;
			while(1){
				if(V[c]>thhold) 
					{clast=clrmap[i*cW+j]= c;  draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, Sclr[c]); break;}
				
				c++; if(c>6) c=0;
				if(c==clast) {clast=0; clrmap[i*cW+j]= NN; break;}
			}
	}
}

void chainup(U8 from, U8 to, U32* chmap, int dir,int i,int j)
{
	int pix = (i)*cW+j;

	if(from==White){ if(to==Black) chmap[pix] += (W2BK)<<(4*dir); 
					 if(to==Blue) chmap[pix] += (W2B)<<(4*dir); }
	else if(from==Black){if(to==White) chmap[pix] += (W2BK)<<(4*dir);
						 if(to==Yellow) chmap[pix]+= (BK2Y)<<(4*dir);}
	else if(from==Blue&&to==White) chmap[pix]+= (W2B)<<(4*dir);
	else if(from==Yellow&&to==Black) chmap[pix]+= (BK2Y)<<(4*dir);
}

void mkchain(U8* clrmap, U32* chmap)
{
	int i, j;
	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		{
			int dir; U8 to;
			U8 from = clrmap[(i)*cW+j];
			chmap[(i)*cW+j] = 0x00000000;

			if(!((from==Red)||(from==Green)||(from==Orange)||(from==NN)))
			for(dir=0;dir<8;dir++)
			switch(dir)
			{
				case 0: if((0<=(i-1)&&(i-1)<cH) && (0<=j&&j<cW))
						{	to = clrmap[(i-1)*cW+j]; chainup(from,to,chmap,dir,i,j);} break;
				case 1: if((0<=(i-1)&&(i-1)<cH) && (0<=(j+1)&&(j+1)<cW))
						{	to = clrmap[(i-1)*cW+j+1]; chainup(from,to,chmap,dir,i,j);}	break;
				case 2: if((0<=(i)&&(i)<cH) && (0<=(j+1)&&(j+1)<cW))
						{	to = clrmap[(i)*cW+j+1]; chainup(from,to,chmap,dir,i,j);} break;
				case 3: if((0<=(i+1)&&(i+1)<cH) && (0<=(j+1)&&(j+1)<cW))
						{	to = clrmap[(i+1)*cW+j+1]; chainup(from,to,chmap,dir,i,j);} break;
				case 4: if((0<=(i+1)&&(i+1)<cH) && (0<=(j)&&(j)<cW))
						{	to = clrmap[(i+1)*cW+j];	chainup(from,to,chmap,dir,i,j);} break;
				case 5: if((0<=(i+1)&&(i+1)<cH) && (0<=(j-1)&&(j-1)<cW))
						{	to = clrmap[(i+1)*cW+j-1]; chainup(from,to,chmap,dir,i,j);} break;
				case 6: if((0<=i&&i<cH) && (0<=(j-1)&&(j-1)<cW))
						{	to = clrmap[(i)*cW+j-1];	chainup(from,to,chmap,dir,i,j);} break;
				default: if((0<=(i-1)&&(i-1)<cH) && (0<=(j-1)&&(j-1)<cW))
						{	to = clrmap[(i-1)*cW+j-1]; chainup(from,to,chmap,dir,i,j);}
			}
		}
}

int cmpCH(U32 CHbuff ,U32 CH)
{
	if(CHbuff==CH) return TRUE;
	else{
		int a1,a2,b1,b2;
		a1 = (CH&0xF0000000)>>(7*4);
		a2 = (CH&0x0F000000)>>(6*4);
		b2 = (CH&0x000000F0)<<(6*4);
		b1 = (CH&0x0000000F)<<(7*4);
		if(CHbuff==((CH<<1)+a1)||CHbuff==((CH<<2)+a2)||CHbuff==((CH>>1)+b1)||CHbuff==((CH>>2)+b2)) return TRUE;
		else return false;
	}
}

void actCH(U32* chmap, U32 act)
{
	int i, j;
	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		{
			if(cmpCH(act,chmap[i*cW+j])) draw_rectfill2(320-(i+1)*13.33, j*13.33, 13.33, 13.33, MAKE_COLORREF(255,0,115));
		}
}

int qcmp(const void *first, const void *second)
{
	Chain c1 = *(Chain*)first;
	Chain c2 = *(Chain*)second;

	if(c1.score > c2.score) return -1;
	else if(c1.score==c2.score) return  0;
	else return 1;
}

void CHclassfier(Chain* CHbuff, U32* chmap)
{
	int bufN=0;

	int i, j;
	for(i=0;i<cH;i++)
		for(j=0;j<cW;j++)
		{
			if(chmap[i*cW+j]!= 0x00000000){
				if(bufN!=0)
				{
					int a;
					for(a=0;a<bufN;a++)
					if(cmpCH(CHbuff[a].ch,chmap[i*cW+j])) break;

					if(a==bufN){
					CHbuff[bufN].ch = chmap[i*cW+j];
					CHbuff[bufN++].score = 1;}
					else CHbuff[a].score++;
				}
				else
				{	CHbuff[bufN].ch = chmap[i*cW+j];
					CHbuff[bufN++].score=1;		}
			}
		}

	qsort((void*)CHbuff,bufN,sizeof(Chain),qcmp);

	CHwrite(CHbuff,bufN);
}

void std_help(int c)
{
	printf("===================\n");
	printf("Color : %d \n",c);
	printf("===================\n");
	printf("White 0\n");
	printf("Black 1\n");
	printf("Yellow 2\n");
	printf("Blue 3\n");
	printf("Red 4\n");
	printf("Green 5\n");
	printf("Orange 6 \n");
	printf("===================\n");
}

void standard(U16* fpga_videodata, U8* clrmap)
{
   int sloop=1;
   
   int c;
   printf("please input c");
   scanf("%d",&c);

   do{
      int sch = getchar();

      switch(sch)
      {   
         case 'Q':
         case 'q': sloop = 0; 
         break;// quit

         case 'H':
	 	 case 'h':
		 std_help(c);
		 break;

         case '1':
         if(0<SR1[c]) SR1[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '2':
         if(SR1[c]<31) SR1[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '3':
         if(0<SG1[c]) SG1[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '4':
         if(SG1[c]<63) SG1[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '5':
         if(0<SB1[c]) SB1[c]--;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '6':
         if(SB1[c]<31) SB1[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '7':
         if(0<SR2[c]) SR2[c]--;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '8':
         if(SR2[c]<31) SR2[c]++;
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d\n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '9':
         if(0<SG2[c]) SG2[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '0':
         if(SG2[c]<63) SG2[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '-':
         if(0<SB2[c]) SB2[c]--; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case '=':
         if(SB2[c]<31) SB2[c]++; 
         printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1[c],SG1[c],SB1[c],SR2[c],SG2[c],SB2[c]);
         coloring(fpga_videodata,clrmap);
         flip();
         break;

         case 'w':
         case 'W':
         printf("what color\n");
         scanf("%d",&c);
      }
   }while(sloop);
}

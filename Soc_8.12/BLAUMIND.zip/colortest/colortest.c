//What is the buf's shape.
//20160717

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "amazon2_sdk.h"
#include "graphic_api.h"

#define Black 0
#define Blue 1
#define Yellow 2
#define Green 3
#define Red 4
#define Orange 5
#define White 6

S8 SR = 16, SG = 32, SB = 16, tol = 4;

void show_help(void)
{
	printf("================================================================\n");
	printf("Color Test\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("a : direct camera display on\n");
	printf("p : read fpga video data \n");
	printf("c : show colored image (o is return)\n");
	printf("1~6 & 0 : control the paraeters for color fitering \n");
	printf("q : exit \n");
	printf("================================================================\n");
}


void coloring(U16* img, U16* Cimg)
{
	int i;
	float d2;

	U8 R,G,B;
	S8 dR, dG, dB;

	for(i=0;i<180*120;i++){
		EXTRACT_RGB565(img[i],R,G,B);

		dR = SR -R; dG = SG - G; dB = SB - B;

		d2 = dR*dR + dG*dG + dB*dB;

		if(d2 < tol) {Cimg[i] = 0xFFFF; }
		else Cimg[i]= 0x0000;

	}
}


int main(void)
{
	int loop=1;

	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U16* colored_image = (U16*)malloc(180 * 120*2);


	if (open_graphic() < 0) {
		return -1;
	}

	show_help();
	
	do{
		int ch = getchar();

		switch(ch)
		{
			case 'Q':
			case 'q': loop = 0; 
			break;// quit

			case 'H':
			case 'h':
			show_help();
			break;

			case 'A':
			case 'a':
			printf("direct camera display on\n");
			direct_camera_display_on();
			break;

			case 'P':
			case 'p':
			printf("Now fpga video data\n");
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;//fpga image read & draw the image

			case 'C':
			case 'c':
			printf("Colored Image\n");
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;// flitering videodata to colored image & draw

			case 'O':
			case 'o':
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;

			// control the parameters(standard R,G,B value) for color fiter--------------------------------
			case '1':
			if(0<SR) SR--; printf("R : %d G : %d B : %d tol : %d\n", SR,SG,SB,tol);
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '2':
			if(SR<31) SR++; printf("R : %d G : %d B : %d tol : %d\n", SR,SG,SB,tol); 
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '3':
			 if(0<SG) SG--; printf("R : %d G : %d B : %d tol : %d\n", SR,SG,SB,tol); 
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '4':
			if(SG<63) SG++; printf("R : %d G : %d B : %d tol : %d\n", SR,SG,SB,tol); 
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '5':
			if(0<SB) SB--; printf("R : %d G : %d B : %d tol : %d\n", SR,SG,SB,tol); 
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '6':
			if(SB<31) SB++; printf("R : %d G : %d B : %d tol : %d\n", SR,SG,SB,tol); 
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '7':
			printf("R : %d G : %d B : %d tol : %d\n", SR,SG,SB,tol); tol--;
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '8':
			printf("R : %d G : %d B : %d tol : %d\n", SR,SG,SB,tol); tol++;
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;
			//-------------------------------------------------------------------------------------------------
		}

	}while(loop);


	free(fpga_videodata);
	close_graphic();

	return 0;
}


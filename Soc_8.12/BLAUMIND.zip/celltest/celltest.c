//What is the buf's shape.
//20160717

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "amazon2_sdk.h"
#include "graphic_api.h"

#define Black 0
#define Blue 1
#define Yellow 2
#define Green 3
#define Red 4
#define Orange 5
#define White 6

U8 SR1 = 0, SG1 = 0, SB1 = 0;
U8 SR2 = 31, SG2 = 63, SB2 = 31;

void show_help(void)
{
	printf("================================================================\n");
	printf("Cell Test\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("a : direct camera display on\n");
	printf("p : Pose Capture \n");
	printf("c : show colored image (o is return)\n");
	printf("1~= : control the paraeters for color fitering \n");
	printf("q : exit \n");
	printf("================================================================\n");
}

void coloring(U16* img, U16* Cimg)
{
	int i,j,cell=6, thhold=24;
	U8 R,G,B;
	clear_screen();

	for(i=0;i<120/cell;i++)
		for(j=0;j<180/cell;j++)
		{
			int a,b,V=0;
			for(a=0;a<cell;a++)
				for(b=0;b<cell;b++)
				{
					EXTRACT_RGB565(img[(i*180 + j)*cell + a*180+b],R,G,B);
					if((SR1<=R&&R<=SR2) && (SG1<=G&&G<=SG2) && (SB1<=B&&B<=SB2)) V++;
				}

			if(V>thhold) draw_rectfill(320-(i+1)*16, j*16, 16, 16, MAKE_COLORREF(255, 255, 0));
	}
}


int main(void)
{
	int loop=1;

	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U16* colored_image = (U16*)malloc(180 * 120*2);


	if (open_graphic() < 0) {
		return -1;
	}

	show_help();
	
	do{
		int ch = getchar();

		switch(ch)
		{
			case 'Q':
			case 'q': loop = 0; 
			break;// quit

			case 'H':
			case 'h':
			show_help();
			break;

			case 'A':
			case 'a':
			printf("direct camera display on\n");
			direct_camera_display_on();
			break;

			case 'P':
			case 'p':
			printf("Now fpga video data\n");
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;//fpga image read & draw the image

			case 'C':
			case 'c':
			printf("Colored Image\n");
			direct_camera_display_off();
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;// flitering videodata to colored image & draw

			case 'O':
			case 'o':
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;

			// control the parameters(standard R,G,B value) for color fiter--------------------------------
			case '1':
			if(0<SR1) SR1--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '2':
			if(SR1<31) SR1++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '3':
			 if(0<SG1) SG1--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '4':
			if(SG1<63) SG1++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '5':
			if(0<SB1) SB1--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '6':
			if(SB1<31) SB1++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '7':
			if(0<SR2) SR2--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '8':
			if(SR2<31) SR2++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '9':
			 if(0<SG2) SG2--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '0':
			if(SG2<63) SG2++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '-':
			if(0<SB2) SB2--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '=':
			if(SB2<31) SB2++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(fpga_videodata, colored_image);
			//draw_fpga_video_data_full(colored_image);
			flip();
			break;

			//-------------------------------------------------------------------------------------------------
		}

	}while(loop);


	free(fpga_videodata);
	free(colored_image);
	close_graphic();

	return 0;
}


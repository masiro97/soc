//20160720

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "amazon2_sdk.h"
#include "graphic_api.h"

#define Black 0
#define Blue 1
#define Yellow 2
#define Green 3
#define Red 4
#define Orange 5
#define White 6

S8 SR1[7] = {16,16,16,16,16,16,16};
S8 SG1[7] = {32,32,32,32,32,32,32}; 
S8 SB1[7] = {16,16,16,16,16,16,16};

S8 SR2[7] = {16,16,16,16,16,16,16};
S8 SG2[7] = {32,32,32,32,32,32,32}; 
S8 SB2[7] = {16,16,16,16,16,16,16};

void show_help(void)
{
	printf("============================================================\n");
	printf("Label Test\n");
	printf("============================================================\n");
	printf("h : show this message\n");
	printf("a : direct camera display on\n");
	printf("p : read fpga video data\n");
	printf("c : show colored image\n");
	printf("l : show labeled image\n");
	printf("o : return to rgb image\n");
	printf("q : exit \n");
	printf("============================================================\n");
}


void coloring(U16* img, U16* Cimg)
{
	int i,j, last=0;

	for(i=0;i<180*120;i++){
		U8 R,G,B;
		EXTRACT_RGB565(img[i],R,G,B);

		do{
		if(SR1[j]<R&&R<SR2[j])
			if(SG1[j]<G&&G<SG2[j])
				if(SB1[j]<B&&B<SB2[j])
		}while(1);
	}
}


int main(void)
{
	int loop=1;

	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U16* colored_image = (U16*)malloc(180 * 120*2);
	U16* labeled_image = (U16*)malloc(180 * 120*2);


	if (open_graphic() < 0) {
		return -1;
	}

	show_help();
	
	do{
		int ch = getchar();

		switch(ch)
		{
			case 'Q':
			case 'q': loop = 0; 
			break;// quit

			case 'H':
			case 'h':
			show_help();
			break;

			case 'A':
			case 'a':
			printf("direct camera display on\n");
			direct_camera_display_on();
			break;

			case 'P':
			case 'p':
			printf("Now fpga video data\n");
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;//fpga image read & draw the image

			case 'C':
			case 'c':
			printf("Colored Image\n");
			direct_camera_display_off();
			coloring(fpga_videodata, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;// flitering videodata to colored image & draw

			case 'L':
			case 'l':
			printf("Labeled Image\n");
			direct_camera_display_off();
			Labeling(fpga_videodata, colored_image, labeled_image);
			draw_fpga_video_data_full(labeled_image);
			flip();
			break;

			case 'O':
			case 'o':
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;
		}

	}while(loop);


	free(fpga_videodata);
	close_graphic();

	return 0;
}


//What is the buf's shape.
//20160717

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "amazon2_sdk.h"
#include "graphic_api.h"

#define Black 0
#define Blue 1
#define Yellow 2
#define Green 3
#define Red 4
#define Orange 5
#define White 6

U8 SR1 = 0, SG1 = 0, SB1 = 0;
U8 SR2 = 31, SG2 = 63, SB2 = 31;

void show_help(void)
{
	printf("================================================================\n");
	printf("Color Test\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("a : direct camera display on\n");
	printf("p : read fpga video data \n");
	printf("c : show colored image (o is return)\n");
	printf("1~= : control the paraeters for color fitering \n");
	printf("q : exit \n");
	printf("================================================================\n");
}

void mean(U16* img, U16* Mimg, int mode)
{
	int r,c;
	U8 R[180*120], G[180*120], B[180*120];

	for(r=0;r<120;r++)
		for(c=0;c<180;c++) EXTRACT_RGB565(img[180*r+c],R[180*r+c],G[180*r+c],B[180*r+c]);

	for(r=1;r<119;r++)
		for(c=1;c<179;c++)
		{
			U16 tempR, tempG, tempB;
			tempR = R[180*(r-1)+c-1]+ R[180*(r-1)+c]+ R[180*(r-1)+c+1]+ 
					R[180*r+c-1]+ R[180*r+c]+ R[180*r+c+1]+
					R[180*(r+1)+c-1]+ R[180*(r+1)+c]+ R[180*(r+1)+c+1];
			tempG = G[180*(r-1)+c-1]+ G[180*(r-1)+c]+ G[180*(r-1)+c+1]+ 
					G[180*r+c-1]+ G[180*r+c]+ G[180*r+c+1]+ 
					G[180*(r+1)+c-1]+ G[180*(r+1)+c]+ G[180*(r+1)+c+1];
			tempB = B[180*(r-1)+c-1]+ B[180*(r-1)+c]+ B[180*(r-1)+c+1]+ 
					B[180*r+c-1]+ B[180*r+c]+ B[180*r+c+1]+ 
					B[180*(r+1)+c-1]+ B[180*(r+1)+c]+ B[180*(r+1)+c+1];

			Mimg[180*r+c] = MAKE_RGB565((tempR/9.+0.5),(tempG/9.+0.5),(tempB/9.+0.5));
			}
		}


void coloring(U16* img, U16* Cimg)
{
	int i;
	U8 R,G,B;

	for(i=0;i<180*120;i++){
		EXTRACT_RGB565(img[i],R,G,B);

		if((SR1<=R&&R<=SR2) && (SG1<=G&&G<=SG2) && (SB1<=B&&B<=SB2)){Cimg[i] = 0xFFFF; }
		else Cimg[i]= 0x0000;

	}
}


int main(void)
{
	int loop=1;

	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U16* filter = (U16*)malloc(180 * 120*2);
//	U16* R = (U16*)malloc(180 * 120*2); U16* G = (U16*)malloc(180 * 120*2); U16* B = (U16*)malloc(180 * 120*2);
	U16* colored_image = (U16*)malloc(180 * 120*2);


	if (open_graphic() < 0) {
		return -1;
	}

	show_help();
	
	do{
		int ch = getchar();

		switch(ch)
		{
			case 'Q':
			case 'q': loop = 0; 
			break;// quit

			case 'H':
			case 'h':
			show_help();
			break;

			case 'A':
			case 'a':
			printf("direct camera display on\n");
			direct_camera_display_on();
			break;

			case 'P':
			case 'p':
			printf("Now fpga video data\n");
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;//fpga image read & draw the image

			case '[':
			printf("Now fpga video data\n");
			mean(fpga_videodata, filter, 0);
			direct_camera_display_off();
			draw_fpga_video_data_full(filter);
			flip();
			break;//fpga image read & draw the image

			case ']':
			printf("Now fpga video data\n");
			mean(fpga_videodata, filter, 1);
			direct_camera_display_off();
			draw_fpga_video_data_full(filter);
			flip();
			break;//fpga image read & draw the image

			case 'C':
			case 'c':
			printf("Colored Image\n");
			direct_camera_display_off();
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;// flitering videodata to colored image & draw

			case 'O':
			case 'o':
			direct_camera_display_off();
			draw_fpga_video_data_full(filter);
			flip();
			break;

			// control the parameters(standard R,G,B value) for color fiter--------------------------------
			case '1':
			if(0<SR1) SR1--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '2':
			if(SR1<31) SR1++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '3':
			 if(0<SG1) SG1--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '4':
			if(SG1<63) SG1++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '5':
			if(0<SB1) SB1--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '6':
			if(SB1<31) SB1++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '7':
			if(0<SR2) SR2--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '8':
			if(SR2<31) SR2++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '9':
			 if(0<SG2) SG2--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '0':
			if(SG2<63) SG2++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '-':
			if(0<SB2) SB2--; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '=':
			if(SB2<31) SB2++; printf("lR : %d lG : %d lB : %d rR : %d rG : %d rB : %d \n", SR1,SG1,SB1,SR2,SG2,SB2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			//-------------------------------------------------------------------------------------------------
		}

	}while(loop);


	free(fpga_videodata);
	free(colored_image);
	free(filter);
	close_graphic();

	return 0;
}


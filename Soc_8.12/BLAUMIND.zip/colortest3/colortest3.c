//What is the buf's shape.
//20160717

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "amazon2_sdk.h"
#include "graphic_api.h"
#include "ama_function.h"

#define Black 0
#define Blue 1
#define Yellow 2
#define Green 3
#define Red 4
#define Orange 5
#define White 6

U8 SH1 = 0, SS1 = 0, SV1 = 0;
U8 SH2 = 180, SS2 = 255, SV2 = 255;

void show_help(void)
{
	printf("================================================================\n");
	printf("Color Test\n");
	printf("================================================================\n");
	printf("h : show this message\n");
	printf("a : direct camera display on\n");
	printf("p : read fpga video data \n");
	printf("c : show colored image (o is return)\n");
	printf("1~= : control the paraeters for color fitering \n");
	printf("q : exit \n");
	printf("================================================================\n");
}

void coloring(U16* img, U16* Cimg)
{
	int i;
	HSV hsv;

	for(i=0;i<180*120;i++){
		hsv = rgb2hsv(img[i]);

		if((SH1<=hsv.h&&hsv.h<=SH2) && (SS1<=hsv.s&&hsv.s<=SS2) && (SV1<=hsv.v&&hsv.v<=SV2)){Cimg[i] = 0xFFFF; }
		else Cimg[i]= 0x0000; 

	}
}


int main(void)
{
	int loop=1;

	U16* fpga_videodata = (U16*)malloc(180 * 120*2);
	U16* filter = (U16*)malloc(180 * 120*2);
	U16* colored_image = (U16*)malloc(180 * 120*2);


	if (open_graphic() < 0) {
		return -1;
	}

	show_help();
	
	do{
		int ch = getchar();

		switch(ch)
		{
			case 'Q':
			case 'q': loop = 0; 
			break;// quit

			case 'H':
			case 'h':
			show_help();
			break;

			case 'A':
			case 'a':
			printf("direct camera display on\n");
			direct_camera_display_on();
			break;

			case 'P':
			case 'p':
			printf("Now fpga video data\n");
			read_fpga_video_data(fpga_videodata);
			direct_camera_display_off();
			draw_fpga_video_data_full(fpga_videodata);
			flip();
			break;//fpga image read & draw the image

			case '[':
			printf("Now fpga video data\n");
			mean(fpga_videodata, filter, 0);
			direct_camera_display_off();
			draw_fpga_video_data_full(filter);
			flip();
			break;//fpga image read & draw the image

			case ']':
			printf("Now fpga video data\n");
			mean(fpga_videodata, filter, 1);
			direct_camera_display_off();
			draw_fpga_video_data_full(filter);
			flip();
			break;//fpga image read & draw the image

			case 'C':
			case 'c':
			printf("Colored Image\n");
			direct_camera_display_off();
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;// flitering videodata to colored image & draw

			case 'O':
			case 'o':
			direct_camera_display_off();
			draw_fpga_video_data_full(filter);
			flip();
			break;

			// control the parameters(standard R,G,B value) for color fiter--------------------------------
			case '1':
			if(0<SH1) SH1--; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '2':
			if(SH1<180) SH1++; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '3':
			 if(0<SS1) SS1--; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '4':
			if(SS1<255) SS1++; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '5':
			if(0<SV1) SV1--; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '6':
			if(SV1<255) SV1++; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '7':
			if(0<SH2) SH2--; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '8':
			if(SH2<180) SH2++; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '9':
			 if(0<SS2) SS2--;printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '0':
			if(SS2<255) SS2++; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '-':
			if(0<SV2) SV2--; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			case '=':
			if(SV2<255) SV2++; printf("lH : %d lS : %d lV : %d rH : %d rS : %d rV : %d \n", SH1,SS1,SV1,SH2,SS2,SV2);
			coloring(filter, colored_image);
			draw_fpga_video_data_full(colored_image);
			flip();
			break;

			//-------------------------------------------------------------------------------------------------
		}

	}while(loop);


	free(fpga_videodata);
	free(colored_image);
	free(filter);
	close_graphic();

	return 0;
}


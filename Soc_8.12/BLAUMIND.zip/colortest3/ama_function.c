//ama_function
#include "amazon2_sdk.h"
#include "ama_function.h"
#include <stdlib.h>
#include <math.h>

extern int SR1,SR2,SG1,SG2,SB1,SB2;

HSV rgb2hsv(U16 data)
{
	RGB rgb;HSV hsv;
	EXTRACT_RGB(MAKE_RGB888FROM565(data),rgb.r,rgb.g,rgb.b);

    float r = rgb.r / 255.0f;
    float g = rgb.g / 255.0f;
    float b = rgb.b / 255.0f;

    float h, s, v; // h:0-360.0, s:0.0-1.0, v:0.0-1.0

    float min = r < g ? (r < b ? r : b) : (g < b ? g : b);
    float max = r > g ? (r > b ? r : b) : (g > b ? g : b);

    v = max;

    if (max == 0.0f) {
        s = 0;
        h = 0;
    }
    else if (max - min == 0.0f) {
        s = 0;
        h = 0;
    }
    else {
        s = (max - min) / max;

        if (max == r) {
            h = 60 * ((g - b) / (max - min)) + 0;
        }
        else if (max == g) {
            h = 60 * ((b - r) / (max - min)) + 120;
        }
        else {
            h = 60 * ((r - g) / (max - min)) + 240;
        }
    }

    if (h < 0) h += 360.0f;

    hsv.h = (unsigned char)(h / 2);   // dst_h : 0-180
    hsv.s = (unsigned char)(s * 255); // dst_s : 0-255
    hsv.v = (unsigned char)(v * 255); // dst_v : 0-255

    return hsv;
}

U16 hsv2rgb(HSV hsv)
{
	RGB rgb;

    float h = hsv.h *   2.0f; // 0-360
    float s = hsv.s / 255.0f; // 0.0-1.0
    float v = hsv.v / 255.0f; // 0.0-1.0

    float r, g, b; // 0.0-1.0

    int   hi = (int)(h / 60.0f) % 6;
    float f  = (h / 60.0f) - hi;
    float p  = v * (1.0f - s);
    float q  = v * (1.0f - s * f);
    float t  = v * (1.0f - s * (1.0f - f));

    switch(hi) {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        default: r = v, g = p, b = q; break;
    }

    rgb.r = (unsigned char)(r * 255); // dst_r : 0-255
    rgb.g = (unsigned char)(g * 255); // dst_r : 0-255
    rgb.b = (unsigned char)(b * 255); // dst_r : 0-255

    return MAKE_RGB565FROM888(MAKE_RGB888((rgb.r+3),(rgb.g+3),(rgb.b+3)));
}

void RGB2HSV(U16* img, U16* Himg)
{
	int i;
	HSV hsv[180*120]; 

	for(i=0;i<180*120;i++) hsv[i] = rgb2hsv(img[i]);
	for(i=0;i<180*120;i++) Himg[i] = hsv2rgb(hsv[i]);
	
}

void mean(U16* img, U16* Mimg, int mode)
{
	int r,c;
	U8 R[180*120], G[180*120], B[180*120];


	for(r=0;r<120;r++)
		for(c=0;c<180;c++) EXTRACT_RGB565(img[180*r+c],R[180*r+c],G[180*r+c],B[180*r+c]);


	if(mode==0){
	for(r=2;r<118;r++)
		for(c=2;c<178;c++)
		{
			U16 tempR, tempG, tempB;
			
			tempR = R[180*(r-2)+c-2]+ R[180*(r-2)+c-1]+ R[180*(r-2)+c]+ R[180*(r-2)+c+1]+ R[180*(r-2)+c+2]+
					R[180*(r-1)+c-2]+ R[180*(r-1)+c]+ R[180*(r-1)+c]+ R[180*(r-1)+c+1]+ R[180*(r-1)+c+2]+
					R[180*r+c-2]+ R[180*r+c-1]+ R[180*r+c]+ R[180*r+c+1]+ R[180*r+c+2]+
					R[180*(r+1)+c-2]+ R[180*(r+1)+c-1]+ R[180*(r+1)+c]+ R[180*(r+1)+c+1]+ R[180*(r+1)+c+2]+
					R[180*(r+2)+c-2]+ R[180*(r+2)+c-1]+ R[180*(r+2)+c]+ R[180*(r+2)+c+1]+ R[180*(r+2)+c+2];

			tempG = G[180*(r-2)+c-2]+ G[180*(r-2)+c-1]+ G[180*(r-2)+c]+ G[180*(r-2)+c+1]+ G[180*(r-2)+c+2]+
					G[180*(r-1)+c-2]+ G[180*(r-1)+c]+ G[180*(r-1)+c]+ G[180*(r-1)+c+1]+ G[180*(r-1)+c+2]+
					G[180*r+c-2]+ G[180*r+c-1]+ G[180*r+c]+ G[180*r+c+1]+ G[180*r+c+2]+
					G[180*(r+1)+c-2]+ G[180*(r+1)+c-1]+ G[180*(r+1)+c]+ G[180*(r+1)+c+1]+ G[180*(r+1)+c+2]+
					G[180*(r+2)+c-2]+ G[180*(r+2)+c-1]+ G[180*(r+2)+c]+ G[180*(r+2)+c+1]+ G[180*(r+2)+c+2];

			tempB = B[180*(r-2)+c-2]+ B[180*(r-2)+c-1]+ B[180*(r-2)+c]+ B[180*(r-2)+c+1]+ B[180*(r-2)+c+2]+
					B[180*(r-1)+c-2]+ B[180*(r-1)+c]+ B[180*(r-1)+c]+ B[180*(r-1)+c+1]+ B[180*(r-1)+c+2]+
					B[180*r+c-2]+ B[180*r+c-1]+ B[180*r+c]+ B[180*r+c+1]+ B[180*r+c+2]+
					B[180*(r+1)+c-2]+ B[180*(r+1)+c-1]+ B[180*(r+1)+c]+ B[180*(r+1)+c+1]+ B[180*(r+1)+c+2]+
					B[180*(r+2)+c-2]+ B[180*(r+2)+c-1]+ B[180*(r+2)+c]+ B[180*(r+2)+c+1]+ B[180*(r+2)+c+2];

			Mimg[180*r+c] = MAKE_RGB565((tempR/25.+0.5),(tempG/25.+0.5),(tempB/25.+0.5));
		}
	}
	else{
	for(r=1;r<119;r++)
		for(c=1;c<179;c++)
		{
			U16 tempR, tempG, tempB;
			tempR = R[180*(r-1)+c-1]+ R[180*(r-1)+c]+ R[180*(r-1)+c+1]+ 
					R[180*r+c-1]+ R[180*r+c]+ R[180*r+c+1]+
					R[180*(r+1)+c-1]+ R[180*(r+1)+c]+ R[180*(r+1)+c+1];
			tempG = G[180*(r-1)+c-1]+ G[180*(r-1)+c]+ G[180*(r-1)+c+1]+ 
					G[180*r+c-1]+ G[180*r+c]+ G[180*r+c+1]+ 
					G[180*(r+1)+c-1]+ G[180*(r+1)+c]+ G[180*(r+1)+c+1];
			tempB = B[180*(r-1)+c-1]+ B[180*(r-1)+c]+ B[180*(r-1)+c+1]+ 
					B[180*r+c-1]+ B[180*r+c]+ B[180*r+c+1]+ 
					B[180*(r+1)+c-1]+ B[180*(r+1)+c]+ B[180*(r+1)+c+1];

			Mimg[180*r+c] = MAKE_RGB565((tempR/9.+0.5),(tempG/9.+0.5),(tempB/9.+0.5));
			}
		}
}


/*
void mean(U16* img, U16* Mimg, int mode)
{
	int i,r,c;
	HSV hsv[180*120]; 

	for(i=0;i<180*120;i++) hsv[i] = rgb2hsv(img[i]);


	if(mode==0){
	for(r=2;r<118;r++)
		for(c=2;c<178;c++)
		{
			U16 tempH, tempS, tempV;
			HSV hsv_t;
			
			tempH = hsv[180*(r-2)+c-2].h+ hsv[180*(r-2)+c-1].h+ hsv[180*(r-2)+c].h+ hsv[180*(r-2)+c+1].h+ hsv[180*(r-2)+c+2].h+
					hsv[180*(r-1)+c-2].h+ hsv[180*(r-1)+c].h+ hsv[180*(r-1)+c].h+ hsv[180*(r-1)+c+1].h+ hsv[180*(r-1)+c+2].h+
					hsv[180*r+c-2].h+ hsv[180*r+c-1].h+ hsv[180*r+c].h+ hsv[180*r+c+1].h+ hsv[180*r+c+2].h+
					hsv[180*(r+1)+c-2].h+ hsv[180*(r+1)+c-1].h+ hsv[180*(r+1)+c].h+ hsv[180*(r+1)+c+1].h+ hsv[180*(r+1)+c+2].h+
					hsv[180*(r+2)+c-2].h+ hsv[180*(r+2)+c-1].h+ hsv[180*(r+2)+c].h+ hsv[180*(r+2)+c+1].h+ hsv[180*(r+2)+c+2].h;

			tempS = hsv[180*(r-2)+c-2].s+ hsv[180*(r-2)+c-1].s+ hsv[180*(r-2)+c].s+ hsv[180*(r-2)+c+1].s+ hsv[180*(r-2)+c+2].s+
					hsv[180*(r-1)+c-2].s+ hsv[180*(r-1)+c].s+ hsv[180*(r-1)+c].s+ hsv[180*(r-1)+c+1].s+ hsv[180*(r-1)+c+2].s+
					hsv[180*r+c-2].s+ hsv[180*r+c-1].s+ hsv[180*r+c].s+ hsv[180*r+c+1].s+ hsv[180*r+c+2].s+
					hsv[180*(r+1)+c-2].s+ hsv[180*(r+1)+c-1].s+ hsv[180*(r+1)+c].s+ hsv[180*(r+1)+c+1].s+ hsv[180*(r+1)+c+2].s+
					hsv[180*(r+2)+c-2].s+ hsv[180*(r+2)+c-1].s+ hsv[180*(r+2)+c].s+ hsv[180*(r+2)+c+1].s+ hsv[180*(r+2)+c+2].s;

			tempV = hsv[180*(r-2)+c-2].v+ hsv[180*(r-2)+c-1].v+ hsv[180*(r-2)+c].v+ hsv[180*(r-2)+c+1].v+ hsv[180*(r-2)+c+2].v+
					hsv[180*(r-1)+c-2].v+ hsv[180*(r-1)+c].v+ hsv[180*(r-1)+c].v+ hsv[180*(r-1)+c+1].v+ hsv[180*(r-1)+c+2].v+
					hsv[180*r+c-2].v+ hsv[180*r+c-1].v+ hsv[180*r+c].v+ hsv[180*r+c+1].v+ hsv[180*r+c+2].v+
					hsv[180*(r+1)+c-2].v+ hsv[180*(r+1)+c-1].v+ hsv[180*(r+1)+c].v+ hsv[180*(r+1)+c+1].v+ hsv[180*(r+1)+c+2].v+
					hsv[180*(r+2)+c-2].v+ hsv[180*(r+2)+c-1].v+ hsv[180*(r+2)+c].v+ hsv[180*(r+2)+c+1].v+ hsv[180*(r+2)+c+2].v;

			hsv_t.h = tempH/25; hsv_t.s = tempS/25; hsv_t.v = tempV/25;
			
			Mimg[180*r+c] = hsv2rgb(hsv_t);
		}
	}
	else{
	for(r=1;r<119;r++)
		for(c=1;c<179;c++)
		{
			U16 tempH, tempS, tempV;
			HSV hsv_t;

			tempH = hsv[180*(r-1)+c].h+ hsv[180*(r-1)+c].h+ hsv[180*(r-1)+c+1].h+ 
					hsv[180*r+c-1].h+ hsv[180*r+c].h+ hsv[180*r+c+1].h+ 
					hsv[180*(r+1)+c-1].h+ hsv[180*(r+1)+c].h+ hsv[180*(r+1)+c+1].h;
					

			tempS = hsv[180*(r-1)+c].s+ hsv[180*(r-1)+c].s+ hsv[180*(r-1)+c+1].s+
					hsv[180*r+c-1].s+ hsv[180*r+c].s+ hsv[180*r+c+1].s+
					hsv[180*(r+1)+c-1].s+ hsv[180*(r+1)+c].s+ hsv[180*(r+1)+c+1].s;


			tempV = hsv[180*(r-1)+c].v+ hsv[180*(r-1)+c].v+ hsv[180*(r-1)+c+1].v+ 
					hsv[180*r+c-1].v+ hsv[180*r+c].v+ hsv[180*r+c+1].v+
					hsv[180*(r+1)+c-1].v+ hsv[180*(r+1)+c].v+ hsv[180*(r+1)+c+1].v;


			hsv_t.h = tempH/9; hsv_t.s = tempS/9; hsv_t.v = tempV/9;

			Mimg[180*r+c] = hsv2rgb(hsv_t);
		}
	}
}
*/


/*
void median(U16* img, U16* Mimg)
{
	int r,c;
	U8 R[180*120], G[180*120], B[180*120];

	for(r=0;r<120;r++)
		for(c=0;c<180;c++) EXTRACT_RGB565(img[180*r+c],R[180*r+c],G[180*r+c],B[180*r+c]);
	
	for(r=1;r<119;r++)
		for(c=1;c<179;c++)
		{
			

			Mimg[180*r+c] = 
		}
}
*/

//ama_function


typedef struct _HSV
{
	U8 h;
	U8 s;
	U8 v;
} HSV;

typedef struct _RGB
{
	U8 r;
	U8 g;
	U8 b;
} RGB;


HSV rgb2hsv(U16 data);
U16 hsv2rgb(HSV hsv);

void mean(U16* img, U16* Mimg, int mode);
void RGB2HSV(U16* img, U16* Himg);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <fcntl.h>
#include <unistd.h>

#include "uart_api.h"

#include <termios.h>
static struct termios inittio, newtio;


#define SCI_BUF_SIZE   4

#define START_CODE    0xFF
#define START_CODE1   0x55
#define Hdata	      0x00
#define Hdata1        0xFF

#define ERROR	0
#define OK	1



void init_console(void);

void DelayLoop(int delay_time);
void Send_Command(unsigned char Ldata, unsigned char Ldata1);
unsigned char Read_Command(void);
int TestItemSelectRobot(void);


void init_stand(void);
void walk(void);
void left(void);
void right(void);
void Lturn(void);
void C6(void);
void C7(void);
void C8(void);
void Rturn(void);
void C10(void);
void C11(void);
void C_c(void);
void C13(void);
void C_r(void);

void wakeup(void);
void hudle(void);
void Swalk(void);
void tuktuk(void);
void RedLoad(void);



#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>	
#include <sys/ioctl.h>

#include "amazon2_sdk.h"
#include "graphic_api.h"

#define cell 5

#define White 0
#define Black 1
#define Yellow 2
#define Blue 3
#define Red 4
#define Green 5
#define Orange 6
#define NN 7

//non 0
#define W2BK 2
#define BK2Y 4
#define W2B 8

//mkchain
#define NOMAL 0
#define TRAND 1

extern U8 SR1[7], SG1[7], SB1[7], SR2[7], SG2[7], SB2[7];

extern EGL_COLOR Sclr[7];

extern const int cW, cH;


typedef struct _chain
{
	U32 ch;
	U8 score;
} Chain;

typedef struct _line
{
	float m;
	EGL_POINT pos;
}Line;

void sdataload(void);
void sdatawrite(void);
void coloring(U16* img, U8* clrmap);
Line mkchain(U8* clrmap, U32* chmap,U8 mode);
void CHclassfier(Chain* CHbuff, U32* chmap);
void actCH(U32* chmap, U32 act);
void standard(U16* fpga_videodata, U8* clrmap);
Line TrendLine(EGL_POINT* pos, int Pn);

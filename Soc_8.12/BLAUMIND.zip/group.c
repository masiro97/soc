
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define cW 18
#define cH 12
#define num_of_feature 5 //특징 개수
#define init_group 10 //그룹 최대 개수

int num_of_group =0; //현재 그룹 개수


typedef struct _group{
   int index; 
   int xpos; int ypos; //현재의 point 저장
   int num_of_point; //그룹에 저장된 포인트 개수
   int ft[num_of_feature];
}Group;

void Init(int x, int y) {

   num_of_point = 0;
   xpos = x;
   ypos = y;
   for (int n = 0; n< num_of_feature;n++) {
      ft[n] = 0;
   }
}

//(i,j)로 부터 맨허튼 거리에 있는 점들을 gpmap에 그린다.
//겹치게 되면 먼저 그려진것을 우선으로 그린다.
void draw_gpmap(int i, int j, int id, int gpmap[]) {
   if (i >= 0 && j >= 0 && gpmap[i*cW + j] == 0) gpmap[i*cW + j] = id;
   if (i + 1 >= 0 && j >= 0 && gpmap[(i + 1)*cW + j] == 0) gpmap[(i + 1)*cW + j] = id;
   if (i+2 >= 0 && j >= 0 && gpmap[(i + 2)*cW + j] == 0) gpmap[(i + 2)*cW + j] = id;
   if (i - 1 >= 0 && j >= 0 && gpmap[(i - 1)*cW + j] == 0) gpmap[(i - 1)*cW + j] = id;
   if (i - 2 >= 0 && j >= 0 && gpmap[(i - 2)*cW + j] == 0) gpmap[(i - 2)*cW + j] = id;
   if (i >= 0 && j + 1 >= 0 && gpmap[i*cW + j + 1] == 0) gpmap[i*cW + j + 1] = id;
   if (i >= 0 && j + 2 >= 0 && gpmap[i*cW + j + 2] == 0) gpmap[i*cW + j + 2] = id;
   if (i >= 0 && j - 1 >= 0 && gpmap[i*cW + j - 1] == 0) gpmap[i*cW + j - 1] = id;
   if (i >= 0 && j - 2 >= 0 && gpmap[i*cW + j - 2] == 0) gpmap[i*cW + j - 2] = id;
   if (i + 1 >= 0 && j + 1 >= 0 && gpmap[(i + 1)*cW + j + 1] == 0) gpmap[(i + 1)*cW + j + 1] = id;
   if (i + 1 >= 0 && j - 1 >= 0 && gpmap[(i + 1)*cW + j - 1] == 0) gpmap[(i + 1)*cW + j - 1] = id;
   if (i - 1 >= 0 && j + 1 >= 0 && gpmap[(i - 1)*cW + j + 1] == 0) gpmap[(i - 1)*cW + j + 1] = id;
   if (i - 1 >= 0 && j - 1 >= 0 && gpmap[(i - 1)*cW + j - 1] == 0) gpmap[(i - 1)*cW + j - 1] = id;
}
//index와 feature를 넣고 gpmap을 그린다.
void mkGroup(int i, int j,int id, int feature, Group Gp, int gpmap[]) {
   Gp.index = id;
   Gp.ft[feature]++;

   draw_gpmap(i, j, Gp.index, gpmap);
}

//그룹화
void Grouping(int i, int  j, int feature, Group Gp[],int gpmap[])
{
      int index = gpmap[i*cW + j];  //index : 현재 gpmap에 그려져 있는 수

      //그룹의 개수가 0개 일떄
      if (num_of_group == 0) {

         mkGroup(i, j, 1, feature, Gp[num_of_group],gpmap);
         Gp[num_of_group].num_of_point++;
         num_of_group++;
      }

      //그룹이 이미 생성되있을 때
      else {
         if (index == 0) {
            //(i,j)가 아무것도 안그려져 있을 때
            //그룹을 생성한다.
            num_of_group++;
            mkGroup(i, j, (num_of_group), feature, Gp[num_of_group-1], gpmap);
            Gp[num_of_group - 1].num_of_point++;
         
         }

         else {
            //(i,j)에 이미 값이 들어가 있는 경우
            mkGroup(i, j, index, feature, Gp[index-1], gpmap);
            Gp[index - 1].num_of_point++;
         }
      }
}

//feature중에서 가장 큰 수 찾기

int max_feature(Group Gp) {

   int arr[num_of_feature];

   for (int k = 0; k < num_of_feature;k++) arr[k] = Gp.ft[k];

   int max = arr[0];

   for (int i = 0; i < 5;i++) {
      if(max < arr[i])
         max = arr[i];
   }
   return max;
}


int main() {

   int* gpmap = (int*)malloc(sizeof(int)*cW*cH);
   
   //gpmap 0으로 초기화
   for (int m = 0; m < cW; m++) {
      for (int n = 0;n <cH ;n++) {
         gpmap[n*cW + m] = 0;
      }
   }

   Group group[init_group];

   //그룹 초기화

   for (int n = 0;n < init_group;n++)
      group[n].Init(0,0);
   
   int feature = 1;
   
   for (int j = 0; j < cH;j++) {
      for (int i = 0; i < cW;i++) {

         if (i == 0 || i == 1 || i == 2 || i == 3) {
            if (j == 0 || j == 1 || j == 2) {
               Grouping(j, i, feature, group, gpmap);
            }
         }



         if (i == 11 || i == 12) {
            if (j == 0 || j == 1) {
               Grouping(j, i, feature, group, gpmap);
            }
         }

         if (i == 0 || i == 1 || i == 2 || i == 3 || i==4 || i ==5 || i==6 || i==7) {
            if (j == 9 || j == 10) {
               Grouping(j, i, feature, group, gpmap);
            }
         }


      }
   }

   printf("-----map----\n");

   for (int m = 0; m < cW*cH; m++) {

      printf("%d  ", gpmap[m]);
      if (m % cW == cW - 1) printf("\n");
   }

   printf("group갯수 : %d\n", num_of_group);
   for (int g = 0;g < num_of_group;g++) {
      printf("group[%d] point : %d\n", g, group[g].num_of_point);
   }

}